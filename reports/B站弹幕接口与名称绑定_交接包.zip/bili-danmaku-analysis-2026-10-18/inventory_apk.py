"""Read DEX string/type/class tables without executing the APK.

Derived APKs contain unchanged manifest + one unchanged DEX, no resources/assets.
They are analysis carriers, not runnable or signature-equivalent applications.
"""
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
APK=Path('C:/Users/zl/Downloads/iBiliPlayer-bili.apk')
for name in ['evidence','derived','reference','examples']:(ROOT/name).mkdir(exist_ok=True)
def u32(data,offset): return struct.unpack_from('<I',data,offset)[0]
def string_at(data,offset):
    pos=offset
    while data[pos]&128:pos+=1
    pos+=1
    end=data.index(0,pos)
    return data[pos:end].decode('utf-8',errors='replace')
records=[]
with zipfile.ZipFile(APK) as archive:
    manifest=archive.read('AndroidManifest.xml')
    for info in sorted(archive.infolist(),key=lambda x:x.filename):
        if not re.fullmatch(r'classes\d*\.dex',info.filename):continue
        data=archive.read(info)
        strings=[string_at(data,u32(data,u32(data,60)+4*i)) for i in range(u32(data,56))]
        types=[strings[u32(data,u32(data,68)+4*i)] for i in range(u32(data,64))]
        names=[types[u32(data,u32(data,100)+32*i)] for i in range(u32(data,96))]
        interesting=[n for n in names if re.search(r'(Danmaku|Danmu|DmMoss|DmGrpc|DmSeg|DmView|DMSeg|Dmlist|Search.*Service|Search.*Api|Video.*Api|Dm.*Req|Dm.*Reply|/dm/v1/)',n)]
        endpoints=[s for s in strings if re.search(r'(?:https?://[^\s]{0,300}(?:bilibili|biliapi)|/x/v2/dm/|/dm/v1/|bilibili\.community\.service\.dm\.v1|^DmSegMobile$|^DmView$)',s)]
        record={'entry':info.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                'class_count':len(names),'matched_classes':interesting,'matched_strings':endpoints}
        records.append(record)
        (ROOT/'evidence'/f'{Path(info.filename).stem}-matches.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'dex':info.filename,'classes':len(names),'hits':len(interesting),
            'interfaces':[n for n in interesting if re.search(r'(Api;|Service;|DmMoss;|DmGrpc;|DmSegMobileReq;|DmSegMobileReply;|DmViewReq;|DmViewReply;)',n)][:18]},ensure_ascii=False))
    (ROOT/'evidence/dex-inventory.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    selected=[r for r in records if any('/community/service/dm/' in n or re.search(r'(DanmakuApi|DanmakuService|DmMoss);',n) for n in r['matched_classes'])]
    for record in selected:
        destination=ROOT/'derived'/f"{Path(record['entry']).stem}.apk"
        with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as out:
            out.writestr('AndroidManifest.xml',manifest)
            out.writestr('classes.dex',archive.read(record['entry']))
        record['derived_path']=str(destination)
        record['derived_sha256']=hashlib.sha256(destination.read_bytes()).hexdigest()
    mapping={'original_path':str(APK),'original_sha256':hashlib.sha256(APK.read_bytes()).hexdigest(),
             'bytes':APK.stat().st_size,'manifest_sha256':hashlib.sha256(manifest).hexdigest(),
             'derived':selected,'limitation':'DEX and manifest bytes unchanged. Other DEX/resources omitted; no signatures or runtime behavior preserved.'}
    (ROOT/'evidence/derived-manifest.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('DERIVED '+json.dumps([r['entry'] for r in selected]))
