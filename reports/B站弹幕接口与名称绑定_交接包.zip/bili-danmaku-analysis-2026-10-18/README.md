# B站弹幕接口与名称绑定研究包

首先阅读 [开发交接文档](B站弹幕接口与按名称绑定_开发交接.md)。本轮用了 REA 对用户提供的 APK 进行静态分析，并独立测试了一个公开投稿的3次HTTP GET；二者证据分别标注。

- [离线解码器说明](examples/README.md)
- [HTTP OpenAPI 模板](api/bilibili-danmaku.openapi.json)
- [Postman 读取模板](api/requests.postman_collection.json)
- [最小 protobuf 字段投影](protocol/bili_danmaku_minimal.proto)
- [REA 证据索引](evidence/rea-evidence-index.json)
- [实际请求记录](evidence/public-api-probe.json)
- [实际解码统计](evidence/public-decode-verification.json)
- [离线测试记录](evidence/codec-verification.json)
- [完整性检查](evidence/verification-summary.json)
- [补充公开协议核验](reference/公开协议核验_弹幕与名称绑定.md)

当前参考解码器与本次元数据/首段响应可离线用于学习与调试。原始 APK 和派生 APK 不打入交接ZIP；本机 derived/ 保留缩小的分析载体，其与原文件字节对应见 derived-manifest.json。跨机器重跑静态分析需用户自行提供同一 APK。

解码与原始协议投影不能自动完成片名匹配、分集识别、版本对齐或 UI 渲染；实现边界与建议步骤已在主文写明。公开参考文件保留其来源提交和许可证，不能冒充本次APK观察。
