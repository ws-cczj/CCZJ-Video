"""Project primitive field descriptors from retained JADX protobuf-lite code.

Analyst-derived schema, linked to REA Evidence; not original .proto recovery.
"""
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent
TYPES={2:'int64',4:'int32',7:'bool',8:'string',9:'message',11:'uint32',12:'enum',
       27:'repeated_message',37:'packed_int64'}
records=[]
for cls in ['DmSegMobileReq','DmSegMobileReply','DanmakuElem','DmViewReq','DmSegConfig']:
    path=ROOT/'evidence'/f'{cls}.dynamicMethod.json'
    if not path.exists(): path=ROOT/'evidence'/f'{cls}.dynamicMethod.0.json'
    raw=json.loads(path.read_text(encoding='utf-8'))
    evidence=raw.get('structuredContent') or json.loads(next(x['text'] for x in raw['content'] if x['type']=='text'))
    source=evidence['normalized_result']['source']['text']
    match=re.search(r'newMessageInfo\(DEFAULT_INSTANCE, ("(?:\\.|[^"\\])*"), new Object\[\]\{([^}]+)\}',source)
    if not match: raise ValueError(cls+' has no recognized protobuf-lite metadata')
    chars=json.loads(match[1])
    codes=[ord(c) for c in chars]
    count=codes[1]
    tail=codes[10:]
    names=re.findall(r'"(\w+_)"',match[2])
    assert len(tail)==count*2 and len(names)==count, cls
    fields=[{'number':tail[i*2],'name':name[:-1],'type':TYPES[tail[i*2+1]&255],
             'lite_type_id':tail[i*2+1]} for i,name in enumerate(names)]
    records.append({'class':cls,'evidence_id':evidence['evidence_id'],'source_file':str(path.relative_to(ROOT)),
                    'projection':'protobuf-lite scalar/repeated descriptor; message payload types corroborated by class inventory',
                    'fields':fields})
(ROOT/'evidence/apk-message-schema.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({r['class']:{f['name']:f['number'] for f in r['fields']} for r in records},ensure_ascii=True))
