# 弹幕接入参考工具

`danmaku_codec.py` 是本次编写的纯标准库参考实现。它只解码本地文件，没有网络请求、登录、发送弹幕或执行 action 的逻辑；也没有实现 UI 渲染和名称搜索。输入必须是**去除传输压缩后的 HTTP protobuf body**，不是 JSON 错误页、gRPC frame 或 Android DmViewReply。

## 直接运行

在 `examples` 目录：

```powershell
python .\test_danmaku_codec.py
python .\danmaku_codec.py ..\evidence\public-dm-segment-1.bin --kind segment -o segment.json
python .\danmaku_codec.py ..\evidence\public-dm-view.bin --kind web-view -o view.json
```

CLI 需要一个本地输入文件；不会因为输入 bvid/cid 就自动发网络请求。输出 JSON 是**本工具的解码/规范化表示**，不是原 API 返回的 JSON。

## 作为模块调用

```python
from danmaku_codec import (
    decode_segment, decode_web_view, segment_index,
    source_ms_from_local, local_ms_from_source, schedule_window,
)

data = decode_segment(open('../evidence/public-dm-segment-1.bin', 'rb').read())
source_ms = source_ms_from_local(361500, offset_ms=1500)  # 360000
if source_ms >= 0:
    index = segment_index(source_ms)  # 2
events = schedule_window(data['elems'], local_start_ms=0,
                         window_ms=1000, offset_ms=1500)
```

`offset_ms>0` 表示弹幕在本地延后出现。`source=local-offset`，`local=source+offset`。source<0 时不发分段请求；`segment_index` 拒绝负值。时间窗口为 `[start,end)`；seek 后按新的播放时刻重算，不沿用旧播放计数器。

默认解码限制：16MiB body、100000条元素、256KiB字符串及有限嵌套。未知字段按 wire type 跳过，截断/错wire/非法varint报 DecodeError；扩展字段不会完整保存在投影里。id/idStr 输出为字符串，保留时间、模式、文本和颜色等字段。

最小调度仅支持普通池、mode1/4/5；mode7等特殊弹幕保留在解码结果，但不进入普通队列。初次接入应将文本作为 textContent/canvas text 渲染，不把 action/content 当代码或HTML执行。

同一 cid 的已解码元素可用 schedule_window 的 ID 去重；**跨cid缓存必须由调用层分开**，不要把不同影片的 elems 混为一个列表。seek/切视频时清空旧渲染队列，旧网络响应通过 generation/cid检查才能入缓存或界面。

## 本次公开样本实际结果

- 207595字节首段，1754条；普通可调度1753条，另有1条mode7。
- Web view给出page_size=360000、total=1、count=2000。
- 首段条数1754不等于元数据count2000；不能推断全量。
- progress最大307953ms，视频详情分P时长却是199秒。先保留原时间戳；不能自动增加offset或强制截断缓存来掩盖不一致。

测试及样本统计保存在 `evidence/codec-verification.json` 和 `public-decode-verification.json`。19项离线测试覆盖时间边界、符号、seek、重复ID、Unicode、proto默认值、state=-1和损坏数据。

根目录 `probe_public_read.py` 是**显式联网**的可选样本复现脚本，固定只读一个公开aid及其第1段，使用普通HTTPS GET，不安装或运行APK；它不提供标题搜索或任意账号绕过。日常开发优先用随包已保存响应做离线调试，避免反复请求服务。
