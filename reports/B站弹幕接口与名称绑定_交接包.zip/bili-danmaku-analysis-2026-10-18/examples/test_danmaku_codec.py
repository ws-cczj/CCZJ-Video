"""Synthetic offline tests; run: python test_danmaku_codec.py --report ../evidence/codec-verification.json."""

import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from danmaku_codec import (DecodeError, decode_segment, decode_web_view, main,
                           local_ms_from_source, source_ms_from_local,
                           segment_index, schedule_window)


def varint(value):
    value &= (1 << 64) - 1
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def vint(field, value):
    return varint(field << 3) + varint(value)


def blob(field, value):
    if isinstance(value, str):
        value = value.encode("utf-8")
    return varint(field << 3 | 2) + varint(len(value)) + value


def element(identity=9007199254740993, progress=0, mode=1, pool=0, text="中文😀"):
    return (vint(1, identity) + vint(2, progress) + vint(3, mode) + vint(4, 25)
            + vint(5, 0x12ABEF) + blob(6, "hash-only") + blob(7, text)
            + vint(8, 1700000000) + vint(9, 8) + blob(10, "javascript:inert()")
            + vint(11, pool) + blob(12, str(identity)) + vint(13, 4) + vint(15, 10))


class CodecTests(unittest.TestCase):
    def test_full_element_unicode_id_color_and_inert_action(self):
        elem = decode_segment(blob(1, element()))["elems"][0]
        self.assertEqual(elem["id"], "9007199254740993")
        self.assertEqual(elem["id_str"], "9007199254740993")
        self.assertEqual(elem["color"], "#12ABEF")
        self.assertEqual(elem["content"], "中文😀")
        self.assertEqual(elem["action"], "javascript:inert()")
        self.assertEqual(elem["ctime_s"], 1700000000)
        self.assertEqual(elem["like_count"], "10")
        self.assertTrue(elem["render_supported"])

    def test_empty_segment_proto3_defaults(self):
        self.assertEqual(decode_segment(b"")["elems"], [])
        self.assertEqual(decode_segment(b"")["state"], 0)
        self.assertEqual(decode_segment(blob(1, b""))["elems"][0]["id"], "0")

    def test_negative_state_int32(self):
        self.assertEqual(decode_segment(vint(2, -1))["state"], -1)

    def test_unknown_wire_types_and_nested_groups(self):
        unknown = (vint(20, 5) + varint(21 << 3 | 1) + b"12345678"
                   + blob(22, b"ignored") + varint(23 << 3 | 5) + b"1234"
                   + varint(24 << 3 | 3) + varint(25 << 3 | 3) + vint(1, 4)
                   + varint(25 << 3 | 4) + varint(24 << 3 | 4))
        result = decode_segment(unknown + blob(1, element() + unknown))
        self.assertEqual(len(result["elems"]), 1)

    def test_duplicate_ids_preserved_decode_deduped_schedule(self):
        raw = blob(1, element(progress=10)) * 2
        elems = decode_segment(raw)["elems"]
        self.assertEqual(len(elems), 2)
        self.assertEqual(len(schedule_window(elems, 0)), 1)

    def test_absent_ids_are_not_collapsed(self):
        elems = decode_segment(blob(1, vint(3, 1)) * 2)["elems"]
        self.assertEqual(len(schedule_window(elems, 0)), 2)

    def test_special_modes_and_pools_preserved_not_scheduled(self):
        elems = decode_segment(b"".join(blob(1, element(i, mode=i))
                                       for i in range(1, 10))
                               + blob(1, element(100, mode=1, pool=2)))["elems"]
        self.assertEqual(len(elems), 10)
        self.assertEqual([e["mode"] for e in schedule_window(elems, 0)], [1, 4, 5])

    def test_boundary_and_parameterized_segments(self):
        self.assertEqual([segment_index(t) for t in (0, 359999, 360000)], [1, 1, 2])
        self.assertEqual(segment_index(100, 100), 2)
        with self.assertRaises(ValueError): segment_index(-1)
        with self.assertRaises(ValueError): segment_index(0, 0)
        with self.assertRaises(TypeError): segment_index(True)

    def test_offset_roundtrip_positive_and_negative(self):
        for offset in (-90000, 0, 90000):
            for local in (0, 400000):
                self.assertEqual(local_ms_from_source(source_ms_from_local(local, offset), offset), local)
        self.assertEqual(source_ms_from_local(10000, 90000), -80000)
        self.assertEqual(local_ms_from_source(10000, -90000), -80000)
        self.assertEqual(local_ms_from_source(0, 90000), 90000)

    def test_seek_recomputes_source_segment_and_window(self):
        offset = 10000
        self.assertEqual(segment_index(source_ms_from_local(370000, offset)), 2)
        elems = decode_segment(blob(1, element(1, 359999))
                               + blob(1, element(2, 360000))
                               + blob(1, element(3, 361000)))["elems"]
        self.assertEqual([e["id"] for e in schedule_window(elems, 370000, 1000, offset)], ["2"])
        self.assertEqual([e["id"] for e in schedule_window(elems, 369999, 1, offset)], ["1"])

    def test_offset_filters_before_local_start(self):
        elems = decode_segment(blob(1, element(1, 0)) + blob(1, element(2, 10000)))["elems"]
        self.assertEqual([e["id"] for e in schedule_window(elems, 0, 1000, -10000)], ["2"])
        self.assertEqual(schedule_window(elems, 0, 1000, 10000), [])
        self.assertEqual([e["id"] for e in schedule_window(elems, 10000, 1000, 10000)], ["1"])
        self.assertEqual(source_ms_from_local(0, 10000), -10000)
        with self.assertRaises(ValueError): segment_index(source_ms_from_local(0, 10000))
        invalid = decode_segment(blob(1, element(3, -1)))["elems"]
        self.assertEqual(schedule_window(invalid, 9000, 1000, 10000), [])

    def test_invalid_varints_and_tags(self):
        for data in (b"\x80", b"\x80" * 10, b"\xff" * 9 + b"\x02", b"\0", b"\x0f"):
            with self.subTest(data=data.hex()), self.assertRaises(DecodeError): decode_segment(data)

    def test_truncated_lengths_fixed_fields_and_groups(self):
        for data in (b"\x0a\x05abc", varint(20 << 3 | 1) + b"12",
                     varint(20 << 3 | 5) + b"12", varint(20 << 3 | 3),
                     varint(20 << 3 | 3) + varint(21 << 3 | 4), varint(20 << 3 | 4)):
            with self.subTest(data=data.hex()), self.assertRaises(DecodeError): decode_segment(data)

    def test_known_fields_wrong_wire(self):
        for data in (vint(1, 1), blob(2, b""), blob(1, blob(2, "wrong")), blob(1, vint(7, 1))):
            with self.assertRaises(DecodeError): decode_segment(data)

    def test_body_element_and_string_resource_limits(self):
        with self.assertRaises(DecodeError): decode_segment(b"123", max_bytes=2)
        with self.assertRaises(DecodeError): decode_segment(blob(1, b"") * 2, max_elements=1)
        with self.assertRaises(DecodeError): decode_segment(blob(1, blob(7, b"x" * (256 * 1024 + 1))))

    def test_group_nesting_limit(self):
        data = varint(20 << 3 | 3) * 18 + varint(20 << 3 | 4) * 18
        with self.assertRaises(DecodeError): decode_segment(data)

    def test_utf8_and_rgb_rejection(self):
        for elem in (blob(7, b"\xff"), vint(5, 0x1000000)):
            with self.assertRaises(DecodeError): decode_segment(blob(1, elem))

    def test_web_view_projection_not_android_message(self):
        result = decode_web_view(vint(1, -1) + blob(4, vint(1, 360000) + vint(2, 3))
                                 + vint(8, 2500) + blob(2, "ignored"))
        self.assertEqual(result, {"message_type": "DmWebViewReply", "state": -1,
                                  "dm_sge": {"page_size": 360000, "total": 3}, "count": "2500"})
        with self.assertRaises(DecodeError): decode_web_view(vint(4, 1))

    def test_cli_local_file(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "input.bin", Path(directory) / "output.json"
            source.write_bytes(blob(1, element()))
            self.assertEqual(main([str(source), "-o", str(output)]), 0)
            self.assertEqual(json.loads(output.read_text(encoding="utf-8"))["elems"][0]["content"], "中文😀")


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.passed = []

    def addSuccess(self, test):
        self.passed.append(test.id())
        super().addSuccess(test)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CodecTests)
    result = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult).run(suite)
    if args.report:
        report = {"network_requests": 0, "fixture_type": "synthetic protobuf, offline",
                  "timeline_convention": {"positive_offset": "delays danmaku on the local video",
                                          "source_ms": "local_ms - offset_ms",
                                          "local_ms": "source_ms + offset_ms",
                                          "negative_source_clock": "no segment request; negative progress records are not scheduled"},
                  "tests_run": result.testsRun, "successful": result.wasSuccessful(),
                  "passed": result.passed,
                  "failures": [str(t) for t, _ in result.failures],
                  "errors": [str(t) for t, _ in result.errors],
                  "source_sha256": hashlib.sha256(Path(__file__).with_name("danmaku_codec.py").read_bytes()).hexdigest()}
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
