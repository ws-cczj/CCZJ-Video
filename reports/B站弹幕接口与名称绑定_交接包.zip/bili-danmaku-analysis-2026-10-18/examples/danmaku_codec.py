"""Offline Bilibili danmaku protobuf projection and timeline helpers (stdlib only).

Decode the *unframed, decompressed HTTP response body*, not a gRPC frame,
JSON error page, or an Android DmViewReply. The web-view projection below is
specifically DmWebViewReply. Unknown protobuf fields are skipped, not retained.
No requests, credentials, posting, midHash reversal, or action execution occur.

CLI: python danmaku_codec.py segment.bin --kind segment -o segment.json
     python danmaku_codec.py view.bin --kind web-view

Timeline convention: offset_ms > 0 delays danmaku on the local video:
source_ms = local_ms - offset_ms; local_ms = source_ms + offset_ms.
Negative source clock values mean the source has not started: do not request a
segment for them. Negative local times are before the local video starts.
Six-minute segments come from the community
protocol reference, not a runtime measurement of this APK, and are configurable.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Iterable


MAX_BODY_BYTES = 16 * 1024 * 1024
MAX_STRING_BYTES = 256 * 1024
MAX_ELEMENTS = 100_000
MAX_GROUP_DEPTH = 16
SUPPORTED_MODES = frozenset((1, 4, 5))


class DecodeError(ValueError):
    """Malformed input or an explicitly configured resource limit was hit."""


class _Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def take(self, size: int) -> bytes:
        if size < 0 or size > len(self.data) - self.pos:
            raise DecodeError(f"truncated field at byte {self.pos}")
        start = self.pos
        self.pos += size
        return self.data[start:self.pos]

    def varint(self) -> int:
        result = 0
        for index in range(10):
            if self.pos >= len(self.data):
                raise DecodeError(f"truncated varint at byte {self.pos}")
            byte = self.data[self.pos]
            self.pos += 1
            if index == 9 and byte > 1:
                raise DecodeError("varint exceeds uint64 / 10 bytes")
            result |= (byte & 127) << (index * 7)
            if byte < 128:
                return result
        raise DecodeError("unterminated varint")

    def tag(self) -> tuple[int, int]:
        tag = self.varint()
        field, wire = tag >> 3, tag & 7
        if not 1 <= field <= 0x1FFFFFFF or wire > 5:
            raise DecodeError("invalid protobuf field number or wire type")
        return field, wire

    def blob(self, limit: int = MAX_BODY_BYTES) -> bytes:
        size = self.varint()
        if size > limit:
            raise DecodeError(f"length-delimited field exceeds {limit} bytes")
        return self.take(size)

    def skip(self, field: int, wire: int, depth: int = 0) -> None:
        if wire == 0:
            self.varint()
        elif wire == 1:
            self.take(8)
        elif wire == 2:
            self.blob()
        elif wire == 3:
            if depth >= MAX_GROUP_DEPTH:
                raise DecodeError("unknown group nesting limit exceeded")
            while self.pos < len(self.data):
                child, child_wire = self.tag()
                if child_wire == 4:
                    if child != field:
                        raise DecodeError("mismatched end-group field")
                    return
                self.skip(child, child_wire, depth + 1)
            raise DecodeError("unterminated protobuf group")
        elif wire == 4:
            raise DecodeError("unexpected end-group")
        elif wire == 5:
            self.take(4)
        else:
            raise DecodeError("invalid protobuf wire type")


def _expect(wire: int, expected: int, field: int) -> None:
    if wire != expected:
        raise DecodeError(f"field {field}: expected wire {expected}, got {wire}")


def _signed(value: int, bits: int) -> int:
    value &= (1 << bits) - 1
    return value - (1 << bits) if value & (1 << (bits - 1)) else value


def _text(reader: _Reader) -> str:
    try:
        return reader.blob(MAX_STRING_BYTES).decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise DecodeError("invalid UTF-8 protobuf string") from error


def _body(data: bytes, max_bytes: int) -> _Reader:
    if not isinstance(data, bytes):
        raise TypeError("data must be bytes")
    if max_bytes < 0 or len(data) > max_bytes:
        raise DecodeError(f"response exceeds {max_bytes} bytes")
    return _Reader(data)


def _decode_element(data: bytes) -> dict:
    result = {
        "id": "0", "progress_ms": 0, "mode": 0, "fontsize": 0,
        "color": "#000000", "mid_hash": "", "content": "", "ctime_s": 0,
        "weight": 0, "action": "", "pool": 0, "id_str": "", "attr": 0,
        "like_count": "0",
    }
    ints = {1: ("id", 64), 2: ("progress_ms", 32), 3: ("mode", 32),
            4: ("fontsize", 32), 8: ("ctime_s", 64), 9: ("weight", 32),
            11: ("pool", 32), 13: ("attr", 32), 15: ("like_count", 64)}
    strings = {6: "mid_hash", 7: "content", 10: "action", 12: "id_str"}
    reader = _Reader(data)
    while reader.pos < len(data):
        field, wire = reader.tag()
        if field in ints:
            _expect(wire, 0, field)
            name, bits = ints[field]
            value = _signed(reader.varint(), bits)
            result[name] = str(value) if name in ("id", "like_count") else value
        elif field == 5:
            _expect(wire, 0, field)
            value = reader.varint()
            if value > 0xFFFFFF:
                raise DecodeError("color is outside the supported RGB24 range")
            result["color"] = f"#{value:06X}"
        elif field in strings:
            _expect(wire, 2, field)
            result[strings[field]] = _text(reader)
        else:
            reader.skip(field, wire)
    # Keep the raw action and special modes as inert data. Never evaluate either.
    result["render_supported"] = result["mode"] in SUPPORTED_MODES and result["pool"] == 0
    return result


def decode_segment(data: bytes, *, max_bytes: int = MAX_BODY_BYTES,
                   max_elements: int = MAX_ELEMENTS) -> dict:
    """Project DmSegMobileReply; preserve order and duplicates for inspection.

    Proto3 omitted fields use defaults. State is a raw signed integer, not a
    Boolean; -1 must not be discarded as a parsing failure. Callers must apply
    endpoint-specific state semantics instead of treating any nonzero as empty.
    """
    reader = _body(data, max_bytes)
    result = {"message_type": "DmSegMobileReply", "state": 0, "elems": []}
    while reader.pos < len(data):
        field, wire = reader.tag()
        if field == 1:
            _expect(wire, 2, field)
            if len(result["elems"]) >= max_elements:
                raise DecodeError("element count limit exceeded")
            result["elems"].append(_decode_element(reader.blob()))
        elif field == 2:
            _expect(wire, 0, field)
            result["state"] = _signed(reader.varint(), 32)
        else:
            reader.skip(field, wire)
    return result


def _decode_seg_config(data: bytes) -> dict:
    result = {"page_size": 0, "total": 0}
    reader = _Reader(data)
    while reader.pos < len(data):
        field, wire = reader.tag()
        if field in (1, 2):
            _expect(wire, 0, field)
            result["page_size" if field == 1 else "total"] = _signed(reader.varint(), 64)
        else:
            reader.skip(field, wire)
    return result


def decode_web_view(data: bytes, *, max_bytes: int = MAX_BODY_BYTES) -> dict:
    """Minimal DmWebViewReply projection, explicitly NOT Android DmViewReply.

    page_size is exposed raw; the helper never assumes its unit or blindly uses
    it as segment_ms. Other config/command/special fields are skipped.
    """
    reader = _body(data, max_bytes)
    result = {"message_type": "DmWebViewReply", "state": 0,
              "dm_sge": {"page_size": 0, "total": 0}, "count": "0"}
    while reader.pos < len(data):
        field, wire = reader.tag()
        if field in (1, 8):
            _expect(wire, 0, field)
            value = _signed(reader.varint(), 32 if field == 1 else 64)
            result["state" if field == 1 else "count"] = value if field == 1 else str(value)
        elif field == 4:
            _expect(wire, 2, field)
            result["dm_sge"].update(_decode_seg_config(reader.blob()))
        else:
            reader.skip(field, wire)
    return result


def _integer(value: int, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{name} must be an integer number of milliseconds")


def segment_index(source_ms: int, segment_ms: int = 360_000) -> int:
    """One-based index. Recompute after a seek using the *source* clock."""
    _integer(source_ms, "source_ms")
    _integer(segment_ms, "segment_ms")
    if source_ms < 0 or segment_ms <= 0:
        raise ValueError("source_ms must be nonnegative and segment_ms positive")
    return source_ms // segment_ms + 1


def source_ms_from_local(local_ms: int, offset_ms: int = 0) -> int:
    """Return source clock; a negative result must not trigger a segment fetch."""
    _integer(local_ms, "local_ms")
    _integer(offset_ms, "offset_ms")
    return local_ms - offset_ms


def local_ms_from_source(source_ms: int, offset_ms: int = 0) -> int:
    """Positive offset delays this source comment on the local timeline."""
    _integer(source_ms, "source_ms")
    _integer(offset_ms, "offset_ms")
    return source_ms + offset_ms


def schedule_window(elems: Iterable[dict], local_start_ms: int,
                    window_ms: int = 1000, offset_ms: int = 0) -> list[dict]:
    """Stateless seek-safe [start, end) window; no renderer or playback clock.

    Only ordinary pool 0, modes 1/4/5 are selected. Duplicate nonzero IDs in
    this input are first-wins; missing IDs stay distinct. Scope cross-segment
    deduplication/cache by CID outside this helper. After seek, clear renderer
    lanes and old work, recompute the required segment, then query this window.
    """
    _integer(local_start_ms, "local_start_ms")
    _integer(window_ms, "window_ms")
    _integer(offset_ms, "offset_ms")
    if local_start_ms < 0 or window_ms <= 0:
        raise ValueError("window start must be nonnegative and duration positive")
    result, seen = [], set()
    for elem in elems:
        identity = elem.get("id_str") or elem.get("id", "0")
        if identity not in ("", "0"):
            if identity in seen:
                continue
            seen.add(identity)
        if elem.get("mode") not in SUPPORTED_MODES or elem.get("pool", 0) != 0:
            continue
        if elem["progress_ms"] < 0:
            continue
        local_ms = local_ms_from_source(elem["progress_ms"], offset_ms)
        if local_start_ms <= local_ms < local_start_ms + window_ms:
            result.append({**elem, "local_ms": local_ms})
    return sorted(result, key=lambda elem: elem["local_ms"])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="local decompressed protobuf response body")
    parser.add_argument("--kind", choices=("segment", "web-view"), default="segment")
    parser.add_argument("-o", "--output", type=Path)
    args = parser.parse_args(argv)
    try:
        # Bounded read also prevents loading an oversized local file into RAM.
        with args.input.open("rb") as stream:
            body = stream.read(MAX_BODY_BYTES + 1)
        decoded = decode_segment(body) if args.kind == "segment" else decode_web_view(body)
        text = json.dumps(decoded, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            args.output.write_text(text, encoding="utf-8")
        else:
            sys.stdout.reconfigure(encoding="utf-8")
            print(text, end="")
        return 0
    except (DecodeError, OSError) as error:
        print(f"decode failed: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
