"""One public sample: metadata + view + first segment; no login or writes.

This is a Web HTTP compatibility probe, not Android runtime capture.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parent
MAX_BYTES=2*1024*1024
records=[]
def fetch(name,path,query):
    url='https://api.bilibili.com'+path+'?'+urlencode(query)
    request=Request(url,headers={'User-Agent':'DanmakuIntegrationStudy/1.0 (read-only)',
                                 'Referer':'https://www.bilibili.com/', 'Accept':'*/*'})
    record={'name':name,'method':'GET','url':url,'request_body':None,'cookies_or_tokens_used':False,
            'observed_at_utc':datetime.now(timezone.utc).isoformat()}
    try:
        try: response=urlopen(request,timeout=20)
        except HTTPError as error: response=error
        with response:
            data=response.read(MAX_BYTES+1)
            record.update(http_status=response.status,content_type=response.headers.get('Content-Type'),
                          content_encoding=response.headers.get('Content-Encoding'),final_url=response.url)
        if len(data)>MAX_BYTES: raise ValueError('bounded response limit exceeded')
        destination=ROOT/'evidence'/f'public-{name}.bin'
        destination.write_bytes(data)
        record.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),file=destination.name)
        try:
            decoded=json.loads(data)
            record['json_envelope']={key:decoded.get(key) for key in ['code','message','ttl'] if key in decoded}
        except (UnicodeError,ValueError): decoded=None
        records.append(record)
        return decoded,record
    except (OSError,ValueError,URLError) as error:
        record['error']=str(error)
        records.append(record)
        return None,record

if __name__=='__main__':
    data,meta=fetch('video-info','/x/web-interface/view',{'aid':'170001'})
    if meta.get('http_status')==200 and isinstance(data,dict) and data.get('code')==0:
        pages=data.get('data',{}).get('pages',[])
        if pages and pages[0].get('cid'):
            cid=str(pages[0]['cid'])
            meta['sample_identity']={'aid':str(data['data'].get('aid','170001')),
                'bvid':data['data'].get('bvid'),'cid':cid,'page':pages[0].get('page'),
                'duration_seconds':pages[0].get('duration')}
            fetch('dm-view','/x/v2/dm/web/view',{'type':'1','oid':cid,'pid':'170001'})
            fetch('dm-segment-1','/x/v2/dm/web/seg.so',{'type':'1','oid':cid,'pid':'170001','segment_index':'1'})
    output={'scope':'one public UGC sample, ordinary Web HTTP GET; not APK runtime',
            'records':records,'original_apk_executed':False,'search_or_pgc_tested':False,
            'all_videos_or_complete_history_claimed':False}
    (ROOT/'evidence/public-api-probe.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=True,indent=2))
