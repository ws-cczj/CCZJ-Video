"""Build API templates, a focused Evidence index, verification, and a ZIP.

No network or target execution. The original APK is not redistributed.
"""
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote
import zipfile

ROOT=Path(__file__).resolve().parent
API=ROOT/'api'
API.mkdir(exist_ok=True)
def dump(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def obj(props,required=()):return {'type':'object','properties':props,'required':list(required),'additionalProperties':True}
def ref(name):return {'$ref':'#/components/schemas/'+name}
def parameter(name,description,required=False,schema=None):
    return {'name':name,'in':'query','required':required,'description':description,'schema':schema or {'type':'string'}}
decimal={'type':'string','pattern':'^[1-9][0-9]*$'}
integer64={'type':'integer','format':'int64'}
json_error=obj({'code':{'type':'integer'},'message':{'type':'string'},'data':{}},['code'])
page=obj({'cid':integer64,'page':{'type':'integer'},'part':{'type':'string'},
          'duration':{'type':'integer','description':'seconds for UGC pages'}},['cid','page'])
schemas={
    'JsonError':json_error,
    'VideoProjection':obj({'code':{'const':0},'message':{'type':'string'},
        'data':obj({'aid':integer64,'bvid':{'type':'string'},'title':{'type':'string'},
                    'pages':{'type':'array','items':page}},['aid','bvid','pages'])},['code','data']),
    'SearchProjection':obj({'code':{'const':0},'data':obj({'result':{'type':'array','items':{'type':'object'}}},['result'])},['code','data']),
    'SeasonProjection':obj({'code':{'const':0},'result':obj({'episodes':{'type':'array','items':obj({
        'id':integer64,'aid':integer64,'cid':integer64,'bvid':{'type':'string'},
        'title':{'type':'string'},'long_title':{'type':'string'}})}},['episodes'])},['code','result']),
    'DecodedElemProjection':obj({'id':{'type':'string'},'idStr':{'type':'string'},
        'progress':{'type':'integer','description':'source absolute ms'},'mode':{'type':'integer'},
        'fontsize':{'type':'integer'},'color':{'type':'integer','minimum':0,'maximum':16777215},
        'content':{'type':'string'},'ctime':{'type':'string','description':'Unix seconds as int64 string'}}),
    'Binding':obj({'provider':{'const':'bilibili'},'localMediaId':{'type':'string'},
        'localEpisodeId':{'type':'string'},'cid':decimal,'aid':decimal,'bvid':{'type':'string'},
        'offsetMs':{'type':'integer','description':'positive delays display on local video'},
        'sourceDurationMs':{'type':'integer'},'targetDurationMs':{'type':'integer'},
        'matchStatus':{'enum':['candidate','confirmed','stale','unbound']}},
        ['provider','localEpisodeId','cid','offsetMs','matchStatus'])
}
def json_response(name):
    return {'description':'按 JSON code 判断业务成功；schema 为已知字段投影',
            'content':{'application/json':{'schema':{'anyOf':[ref(name),ref('JsonError')]}}}}
def operation(name,parameters,reply,observed=False):
    return {'summary':name,'description':'GET 无请求体；访问权限与风控由当前请求环境决定',
        'parameters':parameters,'x-live-sample-observed':observed,'responses':{'200':reply,
            '403':{'description':'访问环境/权限拒绝，正文格式需先检查'},
            '412':{'description':'风控或请求环境拒绝'},'429':{'description':'请求频率限制'}}}
base_dm=[parameter('type','普通视频为1',True,{'type':'integer','enum':[1]}),
         parameter('oid','单分P/单集cid，不是aid',True,decimal),
         parameter('pid','对应投稿aid，可选',False,decimal)]
def binary(message):
    return {'description':'成功为原始 protobuf body（不是JSON、没有gRPC前缀）',
        'content':{'application/octet-stream':{'schema':{'type':'string','format':'binary'},
                                               'x-protobuf-message':message},
                   'application/json':{'schema':ref('JsonError'),'x-condition':'业务错误可能用JSON返回'}}}
paths={
    '/x/web-interface/view':{'get':operation('投稿详情/选择pages[].cid',[
        parameter('aid','aid/bvid至少选一个',False,decimal),parameter('bvid','aid/bvid至少选一个')],
        json_response('VideoProjection'),True)},
    '/x/web-interface/wbi/search/type':{'get':operation('分类搜索（本次未在线测试）',[
        parameter('search_type','候选类别',True,{'enum':['video','media_bangumi','media_ft']}),
        parameter('keyword','UTF-8关键词',True),parameter('page','一基分页',False,{'type':'integer','minimum':1}),
        parameter('wts','本次WBI Unix秒时间戳',True,integer64),
        parameter('w_rid','本次请求签名，不是文档固定值',True)],json_response('SearchProjection'))},
    '/pgc/view/web/season':{'get':operation('番剧/影视单集（本次未在线测试）',[
        parameter('season_id','season_id/ep_id至少选一个',False,decimal),
        parameter('ep_id','season_id/ep_id至少选一个',False,decimal)],json_response('SeasonProjection'))},
    '/x/v2/dm/web/view':{'get':operation('Web弹幕配置',base_dm,binary('DmWebViewReply'),True)},
    '/x/v2/dm/web/seg.so':{'get':operation('普通弹幕分段',base_dm+[
        parameter('segment_index','从1起，当前普通视频按360000ms分段',True,{'type':'integer','minimum':1})],
        binary('DmSegMobileReply'),True)}
}
api={'openapi':'3.1.0','info':{'title':'B站弹幕读取研究：Web适配器','version':'1.0.0',
    'description':'内部协议研究，非官方稳定开放API。3条路由有单样本在线观察；搜索/PGC未测。认证和WBI不在本模板中伪造。'},
    'servers':[{'url':'https://api.bilibili.com'}],'paths':paths,'components':{'schemas':schemas},
    'x-android-grpc':{'host':'grpc.biliapi.net','port':443,
        'methods':['/bilibili.community.service.dm.v1.DM/DmView','/bilibili.community.service.dm.v1.DM/DmSegMobile'],
        'transport':'HTTP2/gRPC/protobuf, not covered as JSON REST operations',
        'evidence':'evidence/grpcstub.getDmSegMobileMethod.json'},
    'x-protobuf-subset':'protocol/bili_danmaku_minimal.proto',
    'x-int64-note':'Actual server JSON may use numbers. Preserve exact int64 using an appropriate parser; normalized storage uses strings.'}
for i,(path,methods) in enumerate(paths.items(),1):methods['get']['operationId']=f'biliRead{i}'
paths['/x/web-interface/view']['get']['x-at-least-one-query']=['aid','bvid']
paths['/pgc/view/web/season']['get']['x-at-least-one-query']=['season_id','ep_id']
schemas['DecodedElemProjection']['description']='Protocol-message readable projection; NOT Python codec normalized output (progress_ms/id_str/ctime_s/hex color).'
dump(API/'bilibili-danmaku.openapi.json',api)
def request(name,url):
    return {'name':name,'request':{'method':'GET','url':url,'header':[
        {'key':'User-Agent','value':'DanmakuIntegrationStudy/1.0 (read-only)'},
        {'key':'Referer','value':'https://www.bilibili.com/'}],
        'description':'Read-only template; no body. This collection is not automatically executed.'},'response':[]}
collection={'info':{'name':'B站弹幕读取与ID绑定样例',
    'schema':'https://schema.getpostman.com/json/collection/v2.1.0/collection.json'},
    'variable':[{'key':key,'value':value,'type':'string'} for key,value in [
        ('aid','170001'),('bvid','BV17x411w7KC'),('cid','279786'),('segment_index','1'),
        ('keyword','REPLACE_WITH_TITLE'),('season_id','REPLACE_WITH_SEASON_ID'),('wts',''),('w_rid','')]],
    'item':[{'name':'本次公开样本：只读','item':[
        request('投稿详情','https://api.bilibili.com/x/web-interface/view?bvid={{bvid}}'),
        request('Web弹幕配置','https://api.bilibili.com/x/v2/dm/web/view?type=1&oid={{cid}}&pid={{aid}}'),
        request('Web分段（响应为protobuf）','https://api.bilibili.com/x/v2/dm/web/seg.so?type=1&oid={{cid}}&pid={{aid}}&segment_index={{segment_index}}')]},
        {'name':'未在线验证的搜索/PGC模板','item':[
        request('WBI分类搜索','https://api.bilibili.com/x/web-interface/wbi/search/type?search_type=video&keyword={{keyword}}&page=1&wts={{wts}}&w_rid={{w_rid}}'),
        request('剧集详情','https://api.bilibili.com/pgc/view/web/season?season_id={{season_id}}')]}]}
dump(API/'requests.postman_collection.json',collection)

index=[]
for path in sorted((ROOT/'evidence').glob('*.json')):
    raw=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(raw,dict):continue
    evidence=raw.get('structuredContent')
    if not evidence and isinstance(raw.get('content'),list):
        for item in raw['content']:
            if item.get('type')=='text':
                try:evidence=json.loads(item['text'])
                except ValueError:pass
                break
    if isinstance(evidence,dict) and 'evidence_id' in evidence:
        result=evidence.get('normalized_result',{})
        index.append({'file':str(path.relative_to(ROOT)),'evidence_id':evidence['evidence_id'],
            'operation':evidence.get('operation'),'subject':evidence.get('subject'),
            'class_name':result.get('class_name'),'method_name':result.get('method',{}).get('name'),
            'limitations':evidence.get('limitations',[])})
dump(ROOT/'evidence/rea-evidence-index.json',index)

# Verify retained references, immutable DEX carrier mapping, and proto field IDs.
mapping=json.loads((ROOT/'evidence/derived-manifest.json').read_text(encoding='utf-8'))
original=Path(mapping['original_path'])
assert hashlib.sha256(original.read_bytes()).hexdigest()==mapping['original_sha256']
with zipfile.ZipFile(original) as archive:
    for record in mapping['derived']:
        carrier=Path(record['derived_path'])
        assert hashlib.sha256(carrier.read_bytes()).hexdigest()==record['derived_sha256']
        with zipfile.ZipFile(carrier) as derived:
            assert derived.read('classes.dex')==archive.read(record['entry'])
            assert derived.read('AndroidManifest.xml')==archive.read('AndroidManifest.xml')
    for record in mapping.get('focused_carriers',[]):
        carrier=Path(record['path'])
        assert hashlib.sha256(carrier.read_bytes()).hexdigest()==record['sha256']
        with zipfile.ZipFile(carrier) as derived:
            for entry in record['original_entries']:assert derived.read(entry)==archive.read(entry)
reference=json.loads((ROOT/'reference/protocol-reference-manifest.json').read_text(encoding='utf-8'))
for record in reference['files']:
    path=ROOT/'reference/bilibili-api-collect'/record['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
schemas=json.loads((ROOT/'evidence/apk-message-schema.json').read_text(encoding='utf-8'))
proto=(ROOT/'protocol/bili_danmaku_minimal.proto').read_text(encoding='utf-8')
def camel(name):return re.sub(r'_([a-z])',lambda m:m[1].upper(),name)
for record in schemas:
    name=record['class']
    match=re.search(r'message '+name+r'\s*\{([^}]+)\}',proto)
    if not match:continue
    actual={camel(f['name']):f['number'] for f in record['fields']}
    for field,num in re.findall(r'\b(?:int64|int32|uint32|string|DanmakuElem)\s+(\w+)\s*=\s*(\d+)\s*;',match[1]):
        assert actual[camel(field)]==int(num),(name,field,num)
probe=json.loads((ROOT/'evidence/public-api-probe.json').read_text(encoding='utf-8'))
for record in probe['records']:
    path=ROOT/'evidence'/record['file']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
decoded=json.loads((ROOT/'evidence/public-decode-verification.json').read_text(encoding='utf-8'))
codec=json.loads((ROOT/'evidence/codec-verification.json').read_text(encoding='utf-8'))
assert decoded['parse_success'] and codec['successful']
assert decoded['decoder_sha256']==hashlib.sha256((ROOT/'examples/danmaku_codec.py').read_bytes()).hexdigest()
all_json=list(ROOT.rglob('*.json'))
for path in all_json:json.loads(path.read_text(encoding='utf-8'))
for path in ROOT.rglob('*.md'):
    text=path.read_text(encoding='utf-8')
    assert '\ufffd' not in text,path.name
    assert sum(line.startswith('```') for line in text.splitlines())%2==0,path.name
    if 'bilibili-api-collect' not in path.parts:
        for block in re.findall(r'^```json\n(.*?)^```',text,re.M|re.S):json.loads(block)
summary={'status':'passed','original_apk_sha256':mapping['original_sha256'],
    'rea_records_saved':len(index),'reference_files_hash_verified':len(reference['files']),
    'public_get_requests':len(probe['records']),'public_segment_elements_decoded':decoded['element_count'],
    'offline_tests':codec['tests_run'],'checks':['original hash and unchanged DEX/manifest carrier bytes',
        'reference SHA256s','minimal proto field IDs vs retained APK descriptor projection',
        'public response SHA256s','decoder identity','JSON syntax and report fenced blocks'],
    'apk_executed':False,'apk_signature_verified':False,'grpc_online_tested':False,
    'search_or_pgc_online_tested':False,'all_history_or_all_videos_claimed':False}
dump(ROOT/'evidence/verification-summary.json',summary)
files=[p for p in ROOT.rglob('*') if p.is_file() and 'derived' not in p.relative_to(ROOT).parts
       and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip','.apk'}]
target=ROOT.parent/'B站弹幕接口与名称绑定_交接包.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(files):packed.write(path,ROOT.name+'/'+path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(target) as packed:assert packed.testzip() is None
print(json.dumps({'verification':summary,'package':str(target),'package_bytes':target.stat().st_size},ensure_ascii=True,indent=2))
