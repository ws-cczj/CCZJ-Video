import hashlib, json, pathlib, urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
REPO = 'bilibili-plugins/bilibili-api-collect'
COMMIT = 'cfc5fddcc8a94b74d91970bb5b4eaeb349addc47'
PATHS = [
 'grpc_api/bilibili/community/service/dm/v1/dm.proto',
 'docs/danmaku/danmaku_proto.md',
 'docs/danmaku/danmaku_view_proto.md',
 'docs/search/search_request.md',
 'docs/search/search_response.md',
 'docs/video/info.md',
 'docs/bangumi/info.md',
 'docs/live/message_stream.md',
 'docs/misc/sign/wbi.md',
 'docs/misc/errcode.md',
 'LICENSE',
]
rows=[]
for path in PATHS:
    url = f'https://raw.githubusercontent.com/{REPO}/{COMMIT}/{path}'
    try:
        data=urllib.request.urlopen(url, timeout=30).read()
    except Exception as e:
        rows.append({'path':path,'error':str(e)})
        continue
    dest=ROOT/'bilibili-api-collect'/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    rows.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'source_url':url,'permalink':f'https://github.com/{REPO}/blob/{COMMIT}/{path}'})
(ROOT/'protocol-reference-manifest.json').write_text(json.dumps({'kind':'community protocol references, NOT APK evidence','retrieved_date':'2026-10-18','repository':REPO,'commit':COMMIT,'files':rows},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'downloaded':sum('error' not in x for x in rows),'errors':[x for x in rows if 'error' in x]},ensure_ascii=True))
