"""Check generated contract subset and capture actual local fixture exchanges.

Uses only standard library. This purpose-built checker implements the JSON
Schema keywords used here; it is not a general OpenAPI/JSON Schema validator.
No requests to fqapp, Legado, or upstream services; no POST is executed.
"""
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
import threading
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'examples'))
from mock_provider import make_server, VIDEO


def resolve(document, pointer):
    assert pointer.startswith('#/'), pointer
    result=document
    for part in pointer[2:].split('/'):
        result=result[part.replace('~1','/').replace('~0','~')]
    return result


def same(a,b):
    # JSON distinguishes boolean and numeric enum values.
    if isinstance(a,bool) != isinstance(b,bool): return False
    return a == b


def check(value, schema, document, path='$'):
    if isinstance(schema,bool):
        assert schema, path
        return
    if '$ref' in schema: check(value,resolve(document,schema['$ref']),document,path)
    for keyword in ['anyOf','oneOf']:
        if keyword in schema:
            successes=0
            for option in schema[keyword]:
                try: check(value,option,document,path)
                except AssertionError: continue
                successes += 1
            assert successes > 0 if keyword == 'anyOf' else successes == 1, (path,keyword,successes)
    if 'not' in schema:
        try: check(value,schema['not'],document,path)
        except AssertionError: pass
        else: raise AssertionError((path,'not'))
    if 'const' in schema: assert same(value,schema['const']), (path,'const')
    if 'enum' in schema: assert any(same(value,v) for v in schema['enum']), (path,'enum')
    types=schema.get('type',[])
    types=[types] if isinstance(types,str) else types
    test={'object':lambda:isinstance(value,dict),'array':lambda:isinstance(value,list),
          'string':lambda:isinstance(value,str),'boolean':lambda:isinstance(value,bool),
          'null':lambda:value is None,
          'integer':lambda:isinstance(value,int) and not isinstance(value,bool),
          'number':lambda:isinstance(value,(int,float)) and not isinstance(value,bool)}
    if types: assert any(test[t]() for t in types), (path,'type',types,type(value).__name__)
    if isinstance(value,dict):
        for key in schema.get('required',[]): assert key in value, (path,'required',key)
        properties=schema.get('properties',{})
        for key,child in value.items():
            if key in properties: check(child,properties[key],document,path+'.'+key)
            elif schema.get('additionalProperties') is False: raise AssertionError((path,'unknown',key))
            elif isinstance(schema.get('additionalProperties'),dict):
                check(child,schema['additionalProperties'],document,path+'.'+key)
    if isinstance(value,list):
        for keyword,valid in [('minItems',lambda n:len(value)>=n),('maxItems',lambda n:len(value)<=n)]:
            if keyword in schema: assert valid(schema[keyword]), (path,keyword)
        if 'items' in schema:
            for i,child in enumerate(value): check(child,schema['items'],document,f'{path}[{i}]')
    if isinstance(value,str):
        if 'minLength' in schema: assert len(value)>=schema['minLength'], (path,'minLength')
        if 'pattern' in schema: assert re.search(schema['pattern'],value), (path,'pattern')
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        if 'minimum' in schema: assert value>=schema['minimum'], (path,'minimum')
        if 'maximum' in schema: assert value<=schema['maximum'], (path,'maximum')


def inspect_spec(document):
    assert document['openapi']=='3.1.0'
    def walk(value):
        if isinstance(value,dict):
            if '$ref' in value: resolve(document,value['$ref'])
            for child in value.values(): walk(child)
        elif isinstance(value,list):
            for child in value: walk(child)
    walk(document)
    for path,methods in document['paths'].items():
        for method,op in methods.items():
            assert method in ['get','post','head']
            placeholders=set(re.findall(r'\{(\w+)\}',path))
            actual={p['name'] for p in op['parameters'] if p['in']=='path' and p['required']}
            assert placeholders==actual, path
            if method in ['get','head']: assert 'requestBody' not in op
            assert op['responses']


def main():
    specs={name:json.loads((ROOT/'api-contracts'/name).read_text(encoding='utf-8')) for name in
           ['fixture.openapi.json','fqapp-read.openapi.json','legado-control.openapi.json']}
    for document in specs.values(): inspect_spec(document)
    fixture=specs['fixture.openapi.json']
    captures=[]
    server=make_server(0)
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    base=f'http://127.0.0.1:{server.server_port}'
    def capture(path, template, expected=200, headers=None, method='GET'):
        request=Request(base+path,headers=headers or {},method=method)
        try: response=urlopen(request,timeout=5)
        except HTTPError as error: response=error
        with response:
            status,reply_headers,body=response.status,dict(response.headers),response.read()
        assert status==expected, (path,status,expected)
        op=fixture['paths'][template][method.lower()]
        contract=op['responses'][str(status)]
        for name,definition in contract.get('headers',{}).items():
            assert name in reply_headers,(path,'missing header',name)
            value=reply_headers[name]
            if definition['schema'].get('type')=='integer': value=int(value)
            check(value,definition['schema'],fixture,'$headers.'+name)
        decoded=None
        if method=='HEAD' or status==416:
            assert body==b'', path
        elif 'application/json' in contract.get('content',{}):
            decoded=json.loads(body)
            assert reply_headers['Content-Type'].startswith('application/json')
            check(decoded,contract['content']['application/json']['schema'],fixture)
        else:
            assert len(body)==int(reply_headers['Content-Length'])
            assert reply_headers['Content-Type'] in contract['content']
        captures.append({'request':{'method':method,'baseUrl':'http://127.0.0.1:{temporaryPort}',
                                    'path':path,'headers':headers or {},'body':None},
            'response':{'status':status,'headers':reply_headers,'json':decoded,'bodyBytes':len(body),
                        'sha256':hashlib.sha256(body).hexdigest()},
            'contract':{'file':'fixture.openapi.json','path':template}})
        return decoded
    try:
        capture('/health','/health')
        search=capture('/v1/search?'+urlencode({'query':'示例','page':1,'pageSize':2}),'/v1/search')
        capture('/v1/search?page=2&pageSize=2','/v1/search')
        capture('/v1/search?query=not-found','/v1/search')
        for kind in ['novel','manga','audio','video']:
            result=capture('/v1/search?kind='+kind,'/v1/search')
            item=result['data']['items'][0]
            detail=capture(item['detailUrl'],'/v1/items/{itemId}')
            catalog=capture(detail['data']['chaptersUrl'],'/v1/items/{itemId}/chapters')
            for chapter in catalog['data']:
                content=capture(chapter['contentUrl'],'/v1/chapters/{chapterId}/content')['data']
                if content['kind']=='images':
                    for page in content['pages']:
                        capture(page['image']['url'],'/assets/panel/{chapterId}/{index}.png')
                if content['kind']=='audio': capture(content['resource']['url'],'/assets/tone.wav')
        capture('/v1/search?page=0','/v1/search',400)
        capture('/v1/search?pageSize=101','/v1/search',400)
        capture('/v1/search?page=abc','/v1/search',400)
        capture('/v1/search?kind=invalid','/v1/search',400)
        capture('/v1/items/missing','/v1/items/{itemId}',404)
        capture('/v1/items/missing/chapters','/v1/items/{itemId}/chapters',404)
        capture('/v1/chapters/missing/content','/v1/chapters/{chapterId}/content',404)
        capture('/assets/tone.wav','/assets/tone.wav',206,{'Range':'bytes=0-9'})
        capture('/assets/tone.wav','/assets/tone.wav',206,{'Range':'bytes=-7'})
        capture('/assets/tone.wav','/assets/tone.wav',416,{'Range':'bytes=999999-'})
        capture('/assets/tone.wav','/assets/tone.wav',416,{'Range':'bytes=0-1,4-5'})
        capture('/assets/tone.wav','/assets/tone.wav',method='HEAD')
        capture('/health','/health',method='HEAD')
        if not VIDEO.is_file(): capture('/assets/sample.mp4','/assets/sample.mp4',404)
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)
    (ROOT/'evidence/api-captures.json').write_text(json.dumps(captures,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    # Independently check selected source-shaped projections (not actual Dart/Kotlin execution).
    fq=specs['fqapp-read.openapi.json']; lg=specs['legado-control.openapi.json']
    positive=[
        (fq,'NovelProjection',{'code':0,'data':{'content':'<p>示例</p>','content_decrypted':True}}),
        (fq,'MangaProjection',{'images':['/src/example.png']}),
        (fq,'AudioProjection',{'code':0,'data':[{'item_id':'chapter','main_url':'https://example.test/a.wav'}]}),
        (fq,'VideoProjection',{'video_id':'v','video_url':'https://example.test/a.mp4','key_hex':'','variants':[]}),
        (fq,'SearchProjection',{'code':0,'data':{'search_tabs':[]}}),
        (fq,'DirectoryProjection',{'code':200,'data':{'data':{'chapterListWithVolume':[[{'itemId':'c'}]]}}}),
        (fq,'DirectoryProjection',{'code':0,'data':{'item_data_list':[{'item_id':'c','version':'v1'}]}}),
        (lg,'Saved',{'isSuccess':True,'errorMsg':'','data':''}),
        (lg,'Text',{'isSuccess':True,'errorMsg':'','data':'正文'}),
        (lg,'Error',{'isSuccess':False,'errorMsg':'未找到'})]
    for document,name,value in positive: check(value,document['components']['schemas'][name],document)
    negative=[
        (fq,'NovelProjection',{'data':{'content':'text','content_decrypted':'true'}}),
        (fq,'NovelProjection',{'data':{'content':'text'}}),
        (fq,'NovelProjection',{'code':'0','data':{'content':'text','content_decrypted':True}}),
        (fq,'MangaProjection',{'images':[{'url':'/a.png'}]}),
        (fq,'MangaProjection',{'images':[]}),
        (fq,'AudioProjection',{'data':{'url':'/a.wav'}}),
        (lg,'Saved',{'isSuccess':'true','errorMsg':'','data':''}),
        (lg,'Text',{'isSuccess':True,'errorMsg':'','data':{'content':'wrong-wrapper'}}),
        (lg,'BookSource',{'bookSourceUrl':'','bookSourceName':'test'}),
        (fixture,'Content',{'data':{'kind':'text','chapterId':'n1-1','text':'x','blocks':[]}})]
    for document,name,value in negative:
        try: check(value,document['components']['schemas'][name],document)
        except AssertionError: pass
        else: raise AssertionError(('negative case accepted',name))
    collection=json.loads((ROOT/'api-contracts/requests.postman_collection.json').read_text(encoding='utf-8'))
    requests=[i['request'] for folder in collection['item'] for i in folder['item']]
    declared={v['key'] for v in collection['variable']}
    for request in requests:
        for variable in re.findall(r'\{\{(\w+)\}\}',request['url']): assert variable in declared
        if request['method']=='GET': assert 'body' not in request
        if 'body' in request: json.loads(request['body']['raw'])
    output={'status':'passed','openapi_documents_checked':len(specs),'live_fixture_exchanges':len(captures),
        'source_projection_positive_cases':len(positive),'negative_cases_rejected':len(negative),
        'postman_request_templates_checked':len(requests),
        'validator_scope':'purpose-built checks for generated JSON Schema subset; not a complete OpenAPI conformance validator',
        'original_apps_or_source_parsers_executed':False,'third_party_requests_made':False,
        'local_application_write_requests_executed':False,'video_decode_tested':False}
    (ROOT/'evidence/api-contract-verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=True,indent=2))


if __name__=='__main__': main()
