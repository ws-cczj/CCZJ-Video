# API 契约、样例与导入

先读 [API 请求响应规范与排错手册](../reports/04_API请求响应规范与排错手册.md)。下面的文件按协议层分开，不能只把基址一换就跨项目复用请求或响应解析器。

| 文件 | 用途 | 事实边界 |
|---|---|---|
| [fixture.openapi.json](fixture.openapi.json) | 本地合成服务的 8 条路径、GET/HEAD、参数和错误 schema | 可请求并核验的确切演示协议 |
| [fqapp-read.openapi.json](fqapp-read.openapi.json) | 8 条核心读取路由的请求和消费端响应投影 | 默认实际走 FFI；HTTP 调试需运行时服务和 capability；未作在线上游验证 |
| [legado-control.openapi.json](legado-control.openapi.json) | 8 条控制路径，含单源/多源导入、读目录正文、保存进度的请求体 | 历史快照本地服务；响应看 isSuccess；部分调用有本地状态写入/同步 |
| [source-examples.json](source-examples.json) | 文档 33 个可解析 JSON 示例，记录所属章节 | 合成值或文档节选，不是第三方真实抓包 |
| [requests.postman_collection.json](requests.postman_collection.json) | 20 个可编辑请求模板 | 本次没有自动执行模板；原应用需用户自己的运行实例 |

## 使用方式

1. OpenAPI 文件为 3.1.0 JSON，可在支持 3.1 的 API 工具中导入。请求参数在 parameters；POST 在 requestBody；按 HTTP 状态区分 responses；公共模型在 components.schemas。
2. Postman 导入 collection，先使用 FIXTURE 文件夹。执行 `python examples/mock_provider.py --port 8765` 后可调用；GET 不加 body。
3. FQ 文件夹设置 fq_base、fq_capability 以及各类 ID。默认端口仅为示例，capability 留空不会自动连接成功。此凭据只给本地 fqapp 服务，不是第三方上游认证。
4. Legado 设置 legado_base、已入库书籍的 legado_bookUrlEncoded。`url` 参数填源标识还是书籍 URL 由操作决定；正文的 url 仍为 bookUrl。
5. collection 的单源/多源 POST 会修改 Legado 本地源配置，不能将它们当成纯读取检查。保存进度规范在 OpenAPI 中，可能影响同步；本次未执行这些原应用写请求。

请求模板没有隐式前置脚本、自动设置 token 或跨站登录。读出 requestId/HTTP status 后，再解析相应业务 envelope；不要按所有接口都 data.items 的方式生成客户端。

## 验证与限制

运行 `python build_api_contracts.py` 重建规范；`python verify_api_contracts.py` 会启动临时端口 mock，采集并检查成功、错误、HEAD 和 Range 响应，写 [api-captures.json](../evidence/api-captures.json) 和 [检查结果](../evidence/api-contract-verification.json)，最后关闭服务。

检查器仅实现本包生成 schema 用到的 `$ref/type/properties/required/additionalProperties/items/enum/const/anyOf/oneOf/not` 及大小/范围约束等子集，不是完整 OpenAPI linter。源项目投影的正反例只检查结构，没有执行 Dart/Kotlin 原解析器。原应用 HTTP、外部书源、Mihon 站点扩展、视频解码仍未运行验证。

fqapp 的部分历史目录/媒体分支不在常用投影 schema 中；投影验证失败表示需按具体响应检查，不证明服务端一定违法。与之相比，fixture schema 是本包自己控制的确切协议。新增实际站点时请保存脱敏真实样本并为那个 provider 单独建立规范，勿把本包合成样本称为真实上游证据。
