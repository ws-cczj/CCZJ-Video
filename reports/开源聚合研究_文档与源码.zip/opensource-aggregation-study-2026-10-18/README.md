# 开源内容聚合项目研究包

推荐直接交给另一个 AI 的文档是 [开源内容聚合项目_完整开发交接.md](开源内容聚合项目_完整开发交接.md)。它合并了开发方案、三个项目的源码分析、请求链和演示接口说明。

版本 1.1 已补充 [API 请求响应规范与排错手册](reports/04_API请求响应规范与排错手册.md)：参数位置/类型、请求体、响应外壳、字段流转、业务错误、二进制读取，以及 OpenAPI/Postman 文件。开发遇到接口问题时先读这一章。

- [开发实施方案](reports/00_聚合项目开发交接.md)
- [fqapp 多媒体分发与请求链](reports/01_fqapp_多媒体分发与请求链.md)
- [Legado 规则引擎与请求链](reports/02_Legado_书源引擎与请求链.md)
- [Mihon 扩展与漫画加载链](reports/03_Mihon_扩展与漫画加载链.md)
- [固定提交源码定位索引](reports/源码定位索引.md)
- [本地演示说明](examples/README.md)
- [机器可读 API 规范与导入说明](api-contracts/README.md)
- [API 实际采样](evidence/api-captures.json)
- [API 契约检查结果](evidence/api-contract-verification.json)
- [原始下载清单](evidence/source-manifest.json)
- [演示验证结果](evidence/verification.json)
- [文档和源码完整性检查](evidence/document-verification.json)
- [Legado 官方仓库状态核验](evidence/repository-provenance.md)

`repos/` 保留三个已解压的源码快照；`evidence/*-source.zip` 保留原始源码压缩包。它们是固定提交 ZIP，而非包含 `.git` 历史的 clone。Legado 实际使用公开历史快照 `CCSSNE/legado`；不是把镜像冒充原仓库当前源码。

交接 ZIP 为节约体积仅携带原始源码压缩包，不重复携带已解压的 `repos/`。若在另一台机器重新做源码行号校验，先将每个源码 ZIP 解压到 `repos/{name}/`，去掉归档顶层的“仓库名-提交号”目录；只阅读报告或运行演示不需要此步骤。

本包分析是定向静态源码分析。原客户端、真实第三方服务、所有边缘分支和真实视频播放没有运行验证。演示 API 是新写的合成数据服务，独立于三个原项目。

重新生成：`python build_citations.py` → `python build_api_contracts.py` → `python verify_api_contracts.py` → `python assemble_handoff.py` → `python verify_documents.py` → `python package_handoff.py`。`verify_api_contracts.py` 只请求自己启动的临时端口 mock，不会执行 Postman 模板或原应用配置写操作。原演示检查仍可用 `python examples/verify_demo.py`。这些步骤不需要构建 Android/Flutter/Rust 应用。
