import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
MANIFEST = {x['name']: x for x in json.loads((ROOT/'evidence/source-manifest.json').read_text(encoding='utf-8'))}
REFS = {}
def add(key, repo, path, start=1, end=None):
    p = ROOT/'repos'/repo/path
    lines = p.read_text(encoding='utf-8-sig').splitlines()
    end = len(lines) if end is None else end
    assert 1 <= start <= end <= len(lines), (key, path, len(lines))
    source = MANIFEST[repo]
    url = f"https://github.com/{source['repository']}/blob/{source['commit']}/{path}#L{start}-L{end}"
    REFS[key] = {'repository':repo,'path':path,'start':start,'end':end,'url':url,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}

for key,path,start,end in [
 ('F01','lib/services/api_client.dart',46,210),('F02','lib/services/api_client.dart',233,343),
 ('F03','rust/src/endpoints/webui.rs',47,169),('F04','rust/src/endpoints/search.rs',34,106),
 ('F05','rust/src/endpoints/webui.rs',171,232),('F06','rust/src/endpoints/webui.rs',371,420),
 ('F07','lib/services/api_client.dart',1091,1171),('F08','rust/src/dispatch.rs',134,200),
 ('F09','rust/src/endpoints/router.rs',23,115),('F10','rust/src/server.rs',82,172),
 ('F11','lib/services/request_gate.dart',23,91),('F12','lib/services/chapter_cache_store.dart',114,159),
 ('F13','lib/services/chapter_download.dart',46,163),('F14','lib/pages/comic_reader_page.dart',150,210),
 ('F15','lib/models/media_item.dart',15,92),('F16','rust/src/upstream/client.rs',122,278),
 ('F17','lib/services/backend_transport.dart',117,300),('F18','lib/services/library_store.dart',81,149),
 ('F19','rust/src/endpoints/router.rs',316,440),('F20','lib/pages/series_detail_page.dart',150,285),
 ('F21','rust/src/endpoints/video.rs',247,404),('F22','lib/services/api_client.dart',377,435),
 ('F23','lib/services/chapter_download.dart',183,240),('F24','rust/src/endpoints/book.rs',98,210),
 ('F25','lib/services/backend_service.dart',1,None),('F26','lib/pages/reader_page.dart',1,None),
 ('F27','rust/src/endpoints/book.rs',65,96),('F28','rust/src/endpoints/content.rs',178,201),
 ('F29','rust/src/endpoints/dhcontent.rs',11,17),('F30','rust/src/endpoints/manga.rs',29,49),
 ('F31','rust/src/endpoints/audio.rs',86,119),('F32','rust/src/endpoints/video.rs',137,195),
 ('F33','rust/src/endpoints/base.rs',11,16),('F34','rust/src/endpoints/base.rs',174,179),
 ('F35','rust/src/endpoints/video.rs',36,45),
 ('F36','lib/services/backend_transport.dart',233,295),('F37','lib/services/backend_transport.dart',320,359),
 ('F38','rust/src/json.rs',98,123),('F39','rust/src/endpoints/webui.rs',25,45),
 ('F40','lib/services/api_client.dart',1429,1478),('F41','lib/models/chapter_media.dart',280,329),
 ('F42','lib/models/media_item.dart',889,964),('F43','lib/models/media_item.dart',138,275),
 ('F44','lib/models/book_detail.dart',185,243),('F45','rust/src/endpoints/webui.rs',232,294),
 ('F46','lib/models/media_item.dart',629,880),('F47','rust/src/endpoints/manga.rs',3016,3042),
 ('F48','lib/models/chapter_media.dart',55,169),('F49','lib/models/series_detail.dart',130,158),
 ('F50','rust/src/endpoints/video.rs',66,132),('F51','rust/src/endpoints/video.rs',452,483),
 ('F52','rust/src/endpoints/base.rs',29,95),('F53','rust/src/dispatch.rs',200,245),
 ('F54','rust/src/error.rs',1,None),
]: add(key,'fqapp',path,start,end)

L='app/src/main/java/io/legado/app/'
for key,path,start,end in [
 ('L01','model/webBook/WebBook.kt',34,87),('L02','model/webBook/WebBook.kt',152,269),
 ('L03','model/webBook/WebBook.kt',299,355),('L04','model/analyzeRule/AnalyzeUrl.kt',140,270),
 ('L05','model/analyzeRule/AnalyzeUrl.kt',400,532),('L06','data/entities/BookSource.kt',31,98),
 ('L07','model/webBook/BookList.kt',35,160),('L08','model/webBook/BookInfo.kt',28,162),
 ('L09','model/webBook/BookChapterList.kt',30,135),('L10','model/webBook/BookContent.kt',35,155),
 ('L11','model/analyzeRule/AnalyzeRule.kt',163,245),('L12','model/webBook/SearchModel.kt',47,109),
 ('L13','model/ReadBook.kt',534,640),('L14','web/HttpServer.kt',25,112),
 ('L15','api/controller/BookController.kt',159,225),('L16','data/entities/rule/TocRule.kt',8,20),
 ('L17','data/entities/rule/ContentRule.kt',12,22),('L18','data/entities/rule/SearchRule.kt',12,25),
 ('L19','data/entities/rule/BookInfoRule.kt',12,25),('L20','model/analyzeRule/AnalyzeRule.kt',532,643),
 ('L22','api/ReturnData.kt',1,None),('L23','web/HttpServer.kt',25,134),
 ('L24','api/controller/BookSourceController.kt',1,None),('L25','data/entities/BookChapter.kt',42,58),
 ('L26','data/entities/BookProgress.kt',1,None),('L27','api/controller/BookController.kt',253,277),
 ('L28','web/socket/BookSearchWebSocket.kt',28,97),('L29','data/entities/SearchBook.kt',30,63),
 ('L30','model/analyzeRule/AnalyzeUrl.kt',682,801),
]: add(key,'legado',L+path,start,end)
add('L21','legado','api.md')

S='source-api/src/main/kotlin/eu/kanade/tachiyomi/source/'
A='app/src/main/java/'
for key,path,start,end in [
 ('M01',S+'Source.kt',14,106),('M02',S+'CatalogueSource.kt',21,47),
 ('M03',S+'online/HttpSource.kt',28,100),('M04',S+'online/HttpSource.kt',162,198),
 ('M05',S+'online/HttpSource.kt',243,357),('M06',S+'online/HttpSource.kt',365,420),
 ('M07','data/src/main/java/tachiyomi/data/source/SourcePagingSource.kt',15,85),
 ('M08',A+'eu/kanade/tachiyomi/ui/manga/MangaViewModel.kt',314,380),
 ('M09',A+'mihon/domain/source/interactor/UpdateMangaFromRemote.kt',55,85),
 ('M10',A+'eu/kanade/domain/chapter/interactor/SyncChaptersWithSource.kt',52,120),
 ('M11',A+'eu/kanade/tachiyomi/ui/reader/loader/ChapterLoader.kt',35,112),
 ('M12',A+'eu/kanade/tachiyomi/ui/reader/loader/HttpPageLoader.kt',43,103),
 ('M13',A+'eu/kanade/tachiyomi/ui/reader/loader/HttpPageLoader.kt',140,258),
 ('M14',A+'eu/kanade/tachiyomi/data/download/Downloader.kt',412,509),
 ('M15',A+'eu/kanade/tachiyomi/data/download/Downloader.kt',576,612),
 ('M16',A+'eu/kanade/tachiyomi/ui/reader/ReaderViewModel.kt',541,710),
 ('M17',A+'eu/kanade/tachiyomi/extension/util/ExtensionLoader.kt',350,425),
 ('M18',A+'eu/kanade/tachiyomi/ui/browse/source/globalsearch/SearchViewModel.kt',130,195),
 ('M19','core/common/src/main/kotlin/eu/kanade/tachiyomi/network/NetworkHelper.kt',30,81),
 ('M20',S+'model/Page.kt',11,57),('M21',S+'online/ParsedHttpSource.kt',15,81),
 ('M22','data/src/main/java/mihon/data/extension/repository/ExtensionStoreRepositoryImpl.kt',114,132),
 ('M23',S+'model/SManga.kt',8,74),('M24',S+'model/SChapter.kt',8,46),
 ('M25',S+'model/MangasPage.kt',3,19),('M26',S+'model/SMangaUpdate.kt',1,None),
]: add(key,'mihon',path,start,end)

(ROOT/'evidence/citations.json').write_text(json.dumps(REFS,ensure_ascii=False,indent=2),encoding='utf-8')
rows=['# 源码定位索引','','所有链接固定到本次下载的提交，行号按原文件；这是定向流程分析，不代表所有分支均运行过。','', '| 编号 | 仓库/文件 | 行 | 固定提交链接 |','|---|---|---:|---|']
for key,r in REFS.items():
    rows.append(f"| {key} | `{r['repository']}/{r['path']}` | {r['start']}–{r['end']} | [{key}]({r['url']}) |")
(ROOT/'reports/源码定位索引.md').write_text('\n'.join(rows)+'\n',encoding='utf-8')
for p in ROOT.glob('**/*.md'):
    if 'repos' in p.relative_to(ROOT).parts:continue
    text=p.read_text(encoding='utf-8')
    text=re.sub(r'\[\[([FLM]\d{2})\]\]',lambda m:f"[{m[1]}]({REFS[m[1]]['url']})",text)
    p.write_text(text,encoding='utf-8')
print(f'Validated {len(REFS)} pinned source references.')
