import hashlib
import io
import json
import pathlib
import re
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
TARGETS = [
    ('fqapp', 'ch6vip/fqapp', '9ada894abac9cc94fded76958c1c71dbf479a754'),
    ('mihon', 'mihonapp/mihon', 'deeb9b2584b6e246135cbd31da49a39e6b6e1e52'),
    ('legado', 'CCSSNE/legado', 'da17bb2'),
]

def get(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'Codex-source-study'})
    with urllib.request.urlopen(request, timeout=90) as response:
        return response.read(), response.url

records = []
for name, repo, revision in TARGETS:
    if len(revision) != 40:
        request = urllib.request.Request(f'https://github.com/{repo}/commit/{revision}.patch', headers={'User-Agent': 'Codex-source-study'})
        with urllib.request.urlopen(request, timeout=30) as response:
            prefix = response.read(2048)
        revision = re.search(rb'^From ([0-9a-f]{40}) ', prefix).group(1).decode()
    url = f'https://codeload.github.com/{repo}/zip/{revision}'
    print(f'Downloading {repo}@{revision}', flush=True)
    body, final_url = get(url)
    archive_path = ROOT / 'evidence' / (name + '-source.zip')
    archive_path.write_bytes(body)
    destination = ROOT / 'repos' / name
    if destination.exists() and any(destination.iterdir()):
        raise RuntimeError('Refusing to overwrite existing source directory: ' + str(destination))
    destination.mkdir(parents=True, exist_ok=True)
    count = 0
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        for item in archive.infolist():
            parts = pathlib.PurePosixPath(item.filename).parts[1:]
            if not parts:
                continue
            target = destination.joinpath(*parts)
            if not target.resolve().is_relative_to(destination.resolve()):
                raise RuntimeError('Unsafe archive path')
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(item))
                count += 1
    record = {'name': name, 'repository': repo, 'commit': revision, 'archive_url': url, 'final_url': final_url, 'archive_sha256': hashlib.sha256(body).hexdigest(), 'archive_bytes': len(body), 'files': count, 'local_directory': str(destination)}
    records.append(record)
    (ROOT / 'evidence' / 'source-manifest.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Extracted {name}: {count} files, {len(body)} bytes', flush=True)
