"""Bundle reports, evidence, demos and original source ZIPs (no duplicate checkout)."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
TARGET = ROOT.parent/'开源聚合研究_文档与源码.zip'
files = [p for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.md', '.py'}]
for name in ['reports', 'examples', 'evidence', 'api-contracts']:
    files.extend(p for p in (ROOT/name).rglob('*') if p.is_file()
                 and '__pycache__' not in p.parts and p.suffix != '.pyc')
with zipfile.ZipFile(TARGET, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
    for path in sorted(set(files)):
        out.write(path, ROOT.name + '/' + path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(TARGET) as packed:
    assert packed.testzip() is None
print(json.dumps({'package':str(TARGET), 'files':len(files), 'bytes':TARGET.stat().st_size,
                  'sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest()}, ensure_ascii=True))
