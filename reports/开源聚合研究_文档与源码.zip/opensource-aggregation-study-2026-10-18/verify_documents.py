"""Check source archives, evidence references, and generated handoff consistency."""
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parent


def verify():
    manifest = json.loads((ROOT/'evidence/source-manifest.json').read_text(encoding='utf-8'))
    citations = json.loads((ROOT/'evidence/citations.json').read_text(encoding='utf-8'))
    for item in manifest:
        archive = ROOT/'evidence'/f"{item['name']}-source.zip"
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == item['archive_sha256']
        with zipfile.ZipFile(archive) as zipped:
            names = {entry.filename: entry for entry in zipped.infolist() if not entry.is_dir()}
            assert len(names) == item['files']
            prefix = next(iter(names)).split('/')[0] + '/'
            for ref in citations.values():
                if ref['repository'] != item['name']:
                    continue
                local = ROOT/'repos'/item['name']/ref['path']
                content = local.read_bytes()
                assert zipped.read(prefix + ref['path']) == content
                assert hashlib.sha256(content).hexdigest() == ref['sha256']
                assert 1 <= ref['start'] <= ref['end'] <= len(content.decode('utf-8-sig').splitlines())
                assert f"/blob/{item['commit']}/" in ref['url']
    documents = [p for p in ROOT.rglob('*.md') if 'repos' not in p.relative_to(ROOT).parts]
    checked_links = 0
    for path in documents:
        text = path.read_text(encoding='utf-8')
        assert not re.search(r'\[\[[FLM]\d+\]\]', text), path.name
        assert '\ufffd' not in text, path.name
        assert sum(1 for line in text.splitlines() if line.startswith('```')) % 2 == 0, path.name
        for label, target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', text):
            if re.fullmatch(r'[FLM]\d{2}', label):
                assert citations[label]['url'] == target
            if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target) and not target.startswith('#'):
                relative = target.split('#')[0]
                if relative:
                    assert (path.parent/unquote(relative)).exists(), (path.name, target)
            checked_links += 1
    combined = (ROOT/'开源内容聚合项目_完整开发交接.md').read_text(encoding='utf-8')
    for path in (ROOT/'reports').glob('0[0-4]_*.md'):
        assert path.read_text(encoding='utf-8') in combined, path.name
    assert (ROOT/'evidence/verification.json').exists()
    return {'status':'passed', 'source_archives':len(manifest), 'pinned_source_references':len(citations),
            'markdown_documents':len(documents), 'links_checked':checked_links,
            'checks':['archive SHA-256 and file counts', 'cited local files equal original ZIP bytes',
                      'source ranges and commit links', 'no citation placeholders or replacement characters',
                      'balanced fenced blocks', 'relative document links exist', 'combined report includes all five reports'],
            'original_apps_built_or_run':False, 'external_content_api_verified':False}


if __name__ == '__main__':
    # Create output path first so README's link to this record can be validated.
    target = ROOT/'evidence/document-verification.json'
    if not target.exists():
        target.write_text('{}\n', encoding='utf-8')
    result = verify()
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=True, indent=2))
