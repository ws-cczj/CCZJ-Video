"""Local, synthetic aggregator fixture. No dependencies or upstream requests."""
from __future__ import annotations

import argparse
import io
import json
import math
from pathlib import Path
import re
import struct
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
import wave
import zlib

HERE = Path(__file__).resolve().parent
VIDEO = HERE / 'assets' / 'sample.mp4'
ITEMS = [
    {'id': 'n1', 'kind': 'novel', 'title': '本地小说示例', 'author': '学习样本', 'chapterCount': 2},
    {'id': 'm1', 'kind': 'manga', 'title': '本地漫画示例', 'author': '程序生成', 'chapterCount': 2},
    {'id': 'v1', 'kind': 'video', 'title': '自有视频示例', 'author': '本地文件', 'chapterCount': 1},
    {'id': 'a1', 'kind': 'audio', 'title': '本地音频示例', 'author': '程序生成', 'chapterCount': 1},
]
BY_ID = {item['id']: item for item in ITEMS}


def item_view(item):
    return dict(item, providerId='fixture', detailUrl=f"/v1/items/{item['id']}",
                chaptersUrl=f"/v1/items/{item['id']}/chapters",
                coverUrl=f"/assets/panel/{item['id']}-1/0.png",
                description='仅包含本地合成数据，无第三方内容。')


def chapters_for(item):
    return [dict(id=f"{item['id']}-{i+1}", itemId=item['id'], order=i,
                 title=f'第 {i+1} 章', contentUrl=f"/v1/chapters/{item['id']}-{i+1}/content")
            for i in range(item['chapterCount'])]


def find_chapter(chapter_id):
    item = BY_ID.get(chapter_id.split('-')[0])
    if item:
        for chapter in chapters_for(item):
            if chapter['id'] == chapter_id:
                return item, chapter
    return None


def content_for(item, chapter):
    cid, kind = chapter['id'], item['kind']
    if kind == 'novel':
        paragraphs = [f"{chapter['title']}：这是本地生成的正文。",
                      '本示例用于验证搜索、详情、目录、内容、缓存与阅读进度的调用顺序。',
                      '切换章节后，应保存稳定的章节标识和段落位置。']
        return {'kind': 'text', 'chapterId': cid, 'text': '\n\n'.join(paragraphs),
                'blocks': [{'id': f'{cid}:p{i}', 'text': p} for i, p in enumerate(paragraphs)]}
    if kind == 'manga':
        return {'kind': 'images', 'chapterId': cid, 'pages': [
            {'index': i, 'image': {'url': f'/assets/panel/{cid}/{i}.png', 'mime': 'image/png'}}
            for i in range(3)]}
    if kind == 'audio':
        return {'kind': 'audio', 'chapterId': cid, 'voiceId': 'synthetic-tone',
                'resource': {'url': '/assets/tone.wav', 'mime': 'audio/wav'}, 'durationMs': 1000}
    available = VIDEO.is_file()
    return {'kind': 'video', 'chapterId': cid, 'available': available,
            'reason': None if available else '请提供自己的 examples/assets/sample.mp4。',
            'variants': [{'id': 'local', 'label': '本地文件', 'format': 'mp4',
                          'resource': {'url': '/assets/sample.mp4', 'mime': 'video/mp4'}}] if available else []}


def png_panel(index):
    """Generate a real RGB PNG with a colored band, not a remote image."""
    width, height = 240, 320
    def chunk(tag, data):
        return struct.pack('!I', len(data)) + tag + data + struct.pack('!I', zlib.crc32(tag + data) & 0xffffffff)
    rows = bytearray()
    for y in range(height):
        rows.append(0)
        color = ((50 + index * 60) % 256, 120 if y < height // 2 else 190, 210)
        rows.extend(bytes(color) * width)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!2I5B', width, height, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b''))


def wav_tone():
    target = io.BytesIO()
    with wave.open(target, 'wb') as out:
        out.setparams((1, 2, 8000, 0, 'NONE', 'not compressed'))
        out.writeframes(b''.join(struct.pack('<h', int(2000 * math.sin(2 * math.pi * 440 * i / 8000)))
                                 for i in range(8000)))
    return target.getvalue()


def byte_range(header, size):
    """Return inclusive single range; reject invalid/unsatisfiable/multiple ranges."""
    match = re.fullmatch(r'bytes=(\d*)-(\d*)', header or '')
    if not match or size <= 0 or not any(match.groups()):
        raise ValueError('Unsupported or invalid byte range')
    a, b = match.groups()
    if not a:
        length = int(b)
        if length <= 0:
            raise ValueError('Invalid suffix')
        return max(0, size - length), size - 1
    start, end = int(a), min(int(b), size - 1) if b else size - 1
    if start >= size or end < start:
        raise ValueError('Unsatisfiable byte range')
    return start, end


class Handler(BaseHTTPRequestHandler):
    server_version = 'LocalFixture/1.0'

    def log_message(self, *args):
        pass  # Do not log user queries or request headers.

    def json_response(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def error_response(self, status, code, message):
        self.json_response(status, {'error': {'code': code, 'message': message}})

    def bytes_response(self, data, mime):
        size = len(data)
        header = self.headers.get('Range')
        try:
            start, end = byte_range(header, size) if header else (0, size - 1)
        except ValueError:
            self.send_response(416)
            self.send_header('Content-Range', f'bytes */{size}')
            self.send_header('Content-Length', '0')
            self.end_headers()
            return
        self.send_response(206 if header else 200)
        self.send_header('Content-Type', mime)
        self.send_header('Accept-Ranges', 'bytes')
        if header:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.send_header('Content-Length', str(end - start + 1))
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data[start:end + 1])

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            self.route()
        except (ValueError, TypeError):
            self.error_response(400, 'BadRequest', '参数格式错误')

    def route(self):
        parsed = urlsplit(self.path)
        path, query = parsed.path, parse_qs(parsed.query, keep_blank_values=True)
        if path == '/health':
            self.json_response(200, {'data': {'status': 'ok', 'provider': 'fixture', 'version': '1'}})
            return
        if path == '/v1/search':
            kind = query.get('kind', [''])[0]
            if kind and kind not in {'novel', 'manga', 'video', 'audio'}:
                raise ValueError('kind')
            keyword = query.get('query', [''])[0].casefold()
            page, page_size = int(query.get('page', ['1'])[0]), int(query.get('pageSize', ['10'])[0])
            if not (1 <= page and 1 <= page_size <= 100):
                raise ValueError('pagination')
            items = [x for x in ITEMS if (not kind or x['kind'] == kind) and keyword in x['title'].casefold()]
            offset = (page - 1) * page_size
            self.json_response(200, {'data': {'items': [item_view(x) for x in items[offset:offset + page_size]],
                'page': page, 'pageSize': page_size, 'total': len(items),
                'hasNextPage': offset + page_size < len(items)}})
            return
        match = re.fullmatch(r'/v1/items/([^/]+)(/chapters)?', path)
        if match:
            item = BY_ID.get(match[1])
            if item is None:
                self.error_response(404, 'NotFound', '条目不存在')
                return
            self.json_response(200, {'data': chapters_for(item) if match[2] else item_view(item)})
            return
        match = re.fullmatch(r'/v1/chapters/([^/]+)/content', path)
        if match:
            found = find_chapter(match[1])
            if found:
                self.json_response(200, {'data': content_for(*found)})
            else:
                self.error_response(404, 'NotFound', '章节不存在')
            return
        match = re.fullmatch(r'/assets/panel/([^/]+)/([0-2])\.png', path)
        if match and find_chapter(match[1]):
            self.bytes_response(png_panel(int(match[2])), 'image/png')
            return
        if path == '/assets/tone.wav':
            self.bytes_response(wav_tone(), 'audio/wav')
            return
        if path == '/assets/sample.mp4' and VIDEO.is_file():
            # Small local demo asset only; production should stream bounded file chunks.
            self.bytes_response(VIDEO.read_bytes(), 'video/mp4')
            return
        self.error_response(404, 'NotFound', '本地资源不存在')


def make_server(port=8765):
    return ThreadingHTTPServer(('127.0.0.1', port), Handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    server = make_server(args.port)
    print(f'Local fixture: http://127.0.0.1:{server.server_port} (Ctrl+C to stop)', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
