"""Verify only the synthetic fixture; never contact an external content service."""
import io
import json
from pathlib import Path
import struct
import threading
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import wave
import zlib

from mock_provider import make_server, byte_range, VIDEO

ROOT = Path(__file__).resolve().parents[1]


def verify():
    server = make_server(0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    checks = []
    def raw(path, headers=None, method='GET'):
        with urlopen(Request(base + path, headers=headers or {}, method=method), timeout=5) as response:
            return response.status, dict(response.headers), response.read()
    def get(path):
        status, _, body = raw(path)
        assert status == 200
        return json.loads(body)['data']
    def expect_error(path, code, headers=None):
        try:
            raw(path, headers)
        except HTTPError as error:
            assert error.code == code, (path, error.code)
            return
        raise AssertionError(f'Expected HTTP {code}: {path}')
    try:
        assert get('/health')['status'] == 'ok'
        for kind, expected in [('novel', 'text'), ('manga', 'images'), ('audio', 'audio'), ('video', 'video')]:
            items = get('/v1/search?' + urlencode({'kind': kind, 'query': '示例'}))['items']
            assert len(items) == 1 and items[0]['kind'] == kind
            detail = get(items[0]['detailUrl'])
            assert detail['id'] == items[0]['id']
            chapters = get(detail['chaptersUrl'])
            assert len(chapters) == detail['chapterCount']
            assert len({c['id'] for c in chapters}) == len(chapters)
            for chapter in chapters:
                content = get(chapter['contentUrl'])
                assert content['kind'] == expected
                if expected == 'text':
                    assert '本地生成' in content['text'] and len(content['blocks']) == 3
                if expected == 'images':
                    for page in content['pages']:
                        _, headers, image = raw(page['image']['url'])
                        assert headers['Content-Type'] == 'image/png' and image.startswith(b'\x89PNG\r\n\x1a\n')
                        offset, pixels = 8, b''
                        while offset < len(image):
                            length = struct.unpack('!I', image[offset:offset + 4])[0]
                            tag = image[offset + 4:offset + 8]
                            data = image[offset + 8:offset + 8 + length]
                            crc = struct.unpack('!I', image[offset + 8 + length:offset + 12 + length])[0]
                            assert zlib.crc32(tag + data) & 0xffffffff == crc
                            if tag == b'IDAT': pixels += data
                            offset += length + 12
                        assert len(zlib.decompress(pixels)) == (240 * 3 + 1) * 320
                if expected == 'audio':
                    _, _, audio = raw(content['resource']['url'])
                    with wave.open(io.BytesIO(audio)) as wav:
                        assert wav.getnframes() == 8000 and wav.getframerate() == 8000
                if expected == 'video':
                    assert content['available'] == VIDEO.is_file()
                    assert bool(content['variants']) == VIDEO.is_file()
            checks.append(f'{kind}: search/detail/chapters/content')
        first = get('/v1/search?page=1&pageSize=2')
        second = get('/v1/search?page=2&pageSize=2')
        assert first['hasNextPage'] and not second['hasNextPage']
        assert len({x['id'] for x in first['items'] + second['items']}) == 4
        assert not get('/v1/search?query=does-not-exist')['items']
        checks.append('pagination: stable ordering, no duplicates, empty query results')
        expect_error('/v1/search?page=0', 400)
        expect_error('/v1/search?kind=unknown', 400)
        expect_error('/v1/items/missing', 404)
        expect_error('/v1/chapters/n1-99/content', 404)
        checks.append('typed HTTP errors: invalid pagination/kind, missing item/chapter')
        status, headers, data = raw('/assets/tone.wav', {'Range': 'bytes=0-9'})
        assert status == 206 and len(data) == 10 and headers['Content-Range'].startswith('bytes 0-9/')
        status, headers, data = raw('/assets/tone.wav', {'Range': 'bytes=-7'})
        assert status == 206 and len(data) == 7
        status, headers, data = raw('/assets/tone.wav', method='HEAD')
        assert status == 200 and len(data) == 0 and int(headers['Content-Length']) > 0
        expect_error('/assets/tone.wav', 416, {'Range': 'bytes=999999-'})
        expect_error('/assets/tone.wav', 416, {'Range': 'bytes=0-1,4-5'})
        assert byte_range('bytes=2-', 10) == (2, 9)
        checks.append('resource transport: PNG CRC/pixels, WAV frames, Range 206/416, HEAD')
        return {'status': 'passed', 'checks': checks,
                'video_asset_present': VIDEO.is_file(), 'real_video_playback_tested': False,
                'original_apps_built_or_run': False, 'external_content_requests_made': False}
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


if __name__ == '__main__':
    result = verify()
    (ROOT / 'evidence' / 'verification.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=True, indent=2))
