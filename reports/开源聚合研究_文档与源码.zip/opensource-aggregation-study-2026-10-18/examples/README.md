# 本地演示接口：接手 AI 的第一个 Provider

这些是本次研究新写的合成 fixture，不是 fqapp/Legado/Mihon 的原始接口，不含外部站点数据。只依赖 Python 标准库；监听 127.0.0.1，不需要任何账号、API key 或网络服务。

## 运行和检查

在 `examples` 目录运行：

```powershell
python .\mock_provider.py --port 8765
# 自动校验（单独进程、临时端口、自动关闭）：
python .\verify_demo.py
```

自动校验不会构建原项目，也不会发起第三方内容请求。它核验四种元数据链、正文、PNG 字节和像素数据、WAV 帧、分页、错误、Range/HEAD。真实播放器解码与 Android 书源导入仍未验证。

## 请求顺序

请求默认 GET。JSON 成功返回 `{ "data": ... }`，失败为 `{ "error": { "code": ..., "message": ... } }`。同源相对资源 URL 用服务基址解析。以下 URL 都是本次新设计的演示协议。

| 阶段 | 请求 | 输出 |
|---|---|---|
| 状态 | `/health` | status/provider/version |
| 搜索 | `/v1/search?kind=novel&query=&page=1&pageSize=10` | items、page、pageSize、total、hasNextPage |
| 详情 | `/v1/items/n1` | id/kind/title/author/detailUrl/chaptersUrl |
| 目录 | `/v1/items/n1/chapters` | id/itemId/order/title/contentUrl |
| 正文 | `/v1/chapters/n1-1/content` | kind=text、blocks、text |
| 漫画目录 | `/v1/items/m1/chapters` | 两章的 contentUrl |
| 漫画页表 | `/v1/chapters/m1-1/content` | kind=images、pages(index,image.url) |
| 图片 | `/assets/panel/m1-1/0.png` | 实际 PNG，三页使用不同颜色 |
| 音频内容 | `/v1/chapters/a1-1/content` | kind=audio、resource.url、durationMs |
| 音频文件 | `/assets/tone.wav` | 1 秒合成 440Hz 低幅度单声道 WAV |
| 视频描述 | `/v1/chapters/v1-1/content` | available 与 variants |
| 自有视频 | `/assets/sample.mp4` | 仅本地资产存在时返回文件 |

`kind` 可为 novel/manga/video/audio，省略则返回全部类型；query 按标题匹配；page 一基，pageSize 1–100。客户端应按 `hasNextPage` 继续，不假定每页一定有 10 条。实际 provider 可能使用 offset 或 opaque cursor，不能照抄本 fixture 的分页语义。

示例：

```powershell
$base = 'http://127.0.0.1:8765'
$search = Invoke-RestMethod "$base/v1/search?kind=novel&page=1&pageSize=10"
$detail = Invoke-RestMethod ($base + $search.data.items[0].detailUrl)
$catalog = Invoke-RestMethod ($base + $detail.data.chaptersUrl)
$content = Invoke-RestMethod ($base + $catalog.data[0].contentUrl)
$content.data.text
```

视频文件未提供。可以创建 `examples/assets`，将自己有权使用的 MP4 放为 `sample.mp4`；服务会将 available 改为 true。演示文件读取会整体入内存，只适合小文件；生产播放器应采用有界分块流式读取。程序不会检查 MP4 编码，文件存在不证明播放器兼容。

静态资源支持单范围 `Range: bytes=start-end`、后缀范围与 HEAD，合法返回 206，无效/不支持的多范围返回 416。此演示没有 ETag/If-Range、鉴权、CORS 策略、生产缓存或任务队列，不能直接当生产后端。

## Legado 风格规则样本

`legado-local-source.json` 映射到小说四阶段：searchUrl → ruleSearch → ruleBookInfo → ruleToc → ruleContent。规则 JSON 结构、JSONPath 路径与 HTTP fixture 可检查；未在 Android 中导入验证，不能称为已经兼容所有版本。

若在 Android 模拟器运行，`127.0.0.1` 指向 Android 自己；可选用 `adb reverse tcp:8765 tcp:8765` 将设备 localhost 转发到开发电脑，再导入规则。不要仅改成电脑公网 IP 暴露本地服务。`adb` 未作为本包依赖安装或执行。

接手 AI 应先实现 FixtureProvider 并规范化响应，再接阅读器、缓存、进度。此服务刻意不实现持久化进度和真实第三方授权；这些正是学习项目需要完成的模块。
