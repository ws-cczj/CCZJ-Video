import pathlib
import sys

sys.stdout.reconfigure(encoding='utf-8')

root = pathlib.Path(__file__).resolve().parent / 'repos' / sys.argv[1]
for selection in sys.argv[2:]:
    parts = selection.rsplit(':', 2)
    if len(parts) == 3 and parts[-1].isdigit() and parts[-2].isdigit():
        file, start, end = parts[0], int(parts[1]), int(parts[2])
    else:
        file, start, end = selection, 1, 100000
    path = root / file
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    print(f'\n{sys.argv[1]}/{file} [{start}-{min(end,len(lines))}, total={len(lines)}]')
    for index in range(start - 1, min(end, len(lines))):
        print(f'{index+1}: {lines[index]}')
