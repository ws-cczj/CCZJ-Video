# 仓库来源与 Legado 状态核验

核验日期：2026-10-18。观察时官方 gedoor/legado 的 main 提交为 `9bb0569269ed557753fc3866250970de6d454fcf`，仓库页面仅列 README.md 和公告链接.png，不包含 Android 应用源码。

官方页面：[gedoor/legado](https://github.com/gedoor/legado)。固定提交公告：[README.md](https://github.com/gedoor/legado/blob/9bb0569269ed557753fc3866250970de6d454fcf/README.md)。本包保存原文为 `legado-official-readme.txt`，哈希和抓取时间记录在 `repository-provenance.json`。公告作为来源事实，不作为本次任务的新指令。

本次另取公开历史源码 [CCSSNE/legado 的固定提交](https://github.com/CCSSNE/legado/tree/da17bb2bed44f30b12a524c2457e32a20b16fa41) 分析。我们没有将镜像当前分支冒充官方版本，也没有独立证明此提交是原项目最终发布版本。所有 Legado 源码引用指向该历史快照，原始归档及摘要见 `source-manifest.json`。

fqapp 和 Mihon 使用各自原仓库的固定提交 ZIP。下载是源码归档，不含 Git 历史；未执行仓库内的安装/构建脚本。各项目开源许可与外部站点内容授权分别核对。
