"""Generate OpenAPI contracts from local fixture behavior and source projections.

No requests are made to original applications or third-party services.
"""
import copy
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'api-contracts'
OUT.mkdir(exist_ok=True)
S = {'type':'string'}
NONEMPTY = {'type':'string','minLength':1}
I = {'type':'integer'}
B = {'type':'boolean'}
NS = {'type':['string','null']}


def obj(properties, required=(), extra=False):
    return {'type':'object','properties':properties,'required':list(required),'additionalProperties':extra}


def array(schema, **kwargs):
    return dict(type='array', items=schema, **kwargs)


def ref(name):
    return {'$ref':'#/components/schemas/'+name}


def envelope(schema):
    return obj({'data':schema}, ['data'])


def param(name, location='query', schema=None, required=False, description=''):
    return {'name':name,'in':location,'required':required,'schema':schema or S,'description':description}


def json_response(schema, description='成功。按响应内业务状态判定可消费性。'):
    return {'description':description,'content':{'application/json':{'schema':schema}}}


def spec(title, layer, schemas, paths, server):
    return {'openapi':'3.1.0','info':{'title':title,'version':'1.1.0',
        'description':('Layer: '+layer+'. See reports/04_API请求响应规范与排错手册.md. '
                       'Source projections are not complete upstream API guarantees.')},
        'servers':[{'url':server,'description':'示例基址，原应用必须改为实际运行实例'}],
        'x-evidence-layer':layer,'paths':paths,'components':{'schemas':schemas}}


def operation(summary, response, parameters=(), body=None, evidence=()):
    op = {'summary':summary,'parameters':list(parameters),'responses':{'200':json_response(response)}}
    if body is not None:
        op['requestBody']={'required':True,'content':{'application/json':{'schema':body}}}
    if evidence:
        op['x-source-references']=list(evidence)
    return op


def write(name, data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


# Exact fixture contract. No authentication, cookies or third-party access.
resource = obj({'url':NONEMPTY,'mime':NONEMPTY}, ['url','mime'])
item = obj({
    'id':NONEMPTY,'kind':{'type':'string','enum':['novel','manga','video','audio']},
    'title':S,'author':S,'chapterCount':{'type':'integer','minimum':1},
    'providerId':{'const':'fixture'},'detailUrl':NONEMPTY,'chaptersUrl':NONEMPTY,
    'coverUrl':NONEMPTY,'description':S,
}, ['id','kind','title','author','chapterCount','providerId','detailUrl','chaptersUrl','coverUrl','description'])
chapter = obj({'id':NONEMPTY,'itemId':NONEMPTY,'order':{'type':'integer','minimum':0},
               'title':S,'contentUrl':NONEMPTY}, ['id','itemId','order','title','contentUrl'])
variant = obj({'id':NONEMPTY,'label':S,'format':{'const':'mp4'},'resource':ref('Resource')},
              ['id','label','format','resource'])
schemas = {
    'Resource':resource,'Item':item,'Chapter':chapter,
    'Health':envelope(obj({'status':{'const':'ok'},'provider':{'const':'fixture'},'version':{'const':'1'}},
                          ['status','provider','version'])),
    'Search':envelope(obj({'items':array(ref('Item')),'page':{'type':'integer','minimum':1},
        'pageSize':{'type':'integer','minimum':1,'maximum':100},'total':{'type':'integer','minimum':0},
        'hasNextPage':B}, ['items','page','pageSize','total','hasNextPage'])),
    'Detail':envelope(ref('Item')),'Catalog':envelope(array(ref('Chapter'))),
    'Text':obj({'kind':{'const':'text'},'chapterId':NONEMPTY,'text':NONEMPTY,
        'blocks':array(obj({'id':NONEMPTY,'text':NONEMPTY},['id','text']), minItems=1)},
        ['kind','chapterId','text','blocks']),
    'Images':obj({'kind':{'const':'images'},'chapterId':NONEMPTY,
        'pages':array(obj({'index':{'type':'integer','minimum':0},'image':ref('Resource')},['index','image']),minItems=1)},
        ['kind','chapterId','pages']),
    'Audio':obj({'kind':{'const':'audio'},'chapterId':NONEMPTY,'voiceId':NONEMPTY,
        'resource':ref('Resource'),'durationMs':{'type':'integer','minimum':1}},
        ['kind','chapterId','voiceId','resource','durationMs']),
    'Video':{'oneOf':[
        obj({'kind':{'const':'video'},'chapterId':NONEMPTY,'available':{'const':False},
             'reason':NONEMPTY,'variants':{'type':'array','maxItems':0}},
            ['kind','chapterId','available','reason','variants']),
        obj({'kind':{'const':'video'},'chapterId':NONEMPTY,'available':{'const':True},
             'reason':{'type':'null'},'variants':array(variant,minItems=1)},
            ['kind','chapterId','available','reason','variants'])]},
    'Content':envelope({'oneOf':[ref(x) for x in ['Text','Images','Audio','Video']]}),
    'Error':obj({'error':obj({'code':{'enum':['BadRequest','NotFound']},'message':NONEMPTY},
                            ['code','message'])},['error'])
}
paths = {
    '/health':{'get':operation('服务状态',ref('Health'))},
    '/v1/search':{'get':operation('标题搜索（GET 无 body）',ref('Search'),[
        param('kind',schema={'enum':['','novel','manga','video','audio'],'default':''}),
        param('query',schema={'type':'string','default':''}),
        param('page',schema={'type':'integer','minimum':1,'default':1}),
        param('pageSize',schema={'type':'integer','minimum':1,'maximum':100,'default':10})])},
    '/v1/items/{itemId}':{'get':operation('条目详情',ref('Detail'),[param('itemId','path',NONEMPTY,True)])},
    '/v1/items/{itemId}/chapters':{'get':operation('无分页目录',ref('Catalog'),[param('itemId','path',NONEMPTY,True)])},
    '/v1/chapters/{chapterId}/content':{'get':operation('按 kind 返回判别联合内容',ref('Content'),
                                                    [param('chapterId','path',NONEMPTY,True)])},
}
for path, methods in list(paths.items()):
    op = methods['get']
    if path == '/v1/search': op['responses']['400']=json_response(ref('Error'),'参数格式错误')
    if '{' in path: op['responses']['404']=json_response(ref('Error'),'条目或章节不存在')
    methods['head']={'summary':'同 GET 的状态和头；响应 body 为空','parameters':copy.deepcopy(op['parameters']),
                     'responses':{code:{'description':v['description']+'（无 body）'} for code,v in op['responses'].items()}}
for path, mime, parameters in [
    ('/assets/panel/{chapterId}/{index}.png','image/png',[
        param('chapterId','path',NONEMPTY,True),param('index','path',{'type':'integer','minimum':0,'maximum':2},True)]),
    ('/assets/tone.wav','audio/wav',[]),('/assets/sample.mp4','video/mp4',[])]:
    binary={'description':'二进制资源；不是 JSON','headers':{
        'Content-Length':{'schema':{'type':'integer','minimum':0}},
        'Accept-Ranges':{'schema':{'const':'bytes'}}},
        'content':{mime:{'schema':{'type':'string','format':'binary'}}}}
    partial=copy.deepcopy(binary)
    partial['description']='单范围二进制响应'
    partial['headers']['Content-Range']={'schema':{'type':'string','pattern':r'^bytes \d+-\d+/\d+$'}}
    op={'summary':'资源读取','parameters':parameters+[param('Range','header',S,False,'仅支持单一 bytes 范围')],
        'responses':{'200':binary,'206':partial,'404':json_response(ref('Error'),'资源不存在'),
            '416':{'description':'空 body；范围无效/不可满足','headers':{
                'Content-Range':{'schema':{'type':'string','pattern':r'^bytes \*/\d+$'}}}}}}
    head=copy.deepcopy(op)
    head['summary']='资源 HEAD；保留对应状态/头，无响应体'
    for response in head['responses'].values(): response.pop('content',None)
    paths[path]={'get':op,'head':head}
write('fixture.openapi.json',spec('学习聚合 Fixture API','FIXTURE / executable',schemas,paths,'http://127.0.0.1:8765'))


# fqapp: schemas describe known successful consumer projections, not every upstream branch.
fq_error=obj({'success':{'const':False},'error':S},['success','error'],True)
fq_schemas={
    'RustError':fq_error,
    'BusinessError':obj({'code':{'type':['number','string'],'not':{'enum':[0,200]}},'message':S},['code'],True),
    'SearchProjection':{'anyOf':[
        obj({'search_tabs':array({'type':'object'})},['search_tabs'],True),
        obj({'data':obj({'search_tabs':array({'type':'object'})},['search_tabs'],True)},['data'],True)]},
    'BookData':obj({'book_id':S,'book_name':S,'abstract':S,'author':S,'thumb_url':S,
                   'detail_page_thumb_url':S,'serial_count':{'type':['integer','string']}},[],True),
    'BookProjection':obj({'data':{'anyOf':[ref('BookData'),obj({'data':ref('BookData')},['data'],True)]}},['data'],True),
    'ChapterProjection':{'type':'object','anyOf':[{'required':[x]} for x in ['itemId','item_id','chapter_id','id']],
        'properties':{x:{'type':['string','number']} for x in ['itemId','item_id','chapter_id','id']},
        'additionalProperties':True},
    'VolumeList':array(array(ref('ChapterProjection'))),
    'DirectoryProjection':{'anyOf':[
        obj({'data':obj({'item_data_list':array(ref('ChapterProjection'))},['item_data_list'],True)},['data'],True),
        obj({'data':obj({'chapterListWithVolume':ref('VolumeList')},['chapterListWithVolume'],True)},['data'],True),
        obj({'data':obj({'data':obj({'chapterListWithVolume':ref('VolumeList')},['chapterListWithVolume'],True)},
                        ['data'],True)},['data'],True)],
        'description':'Known common shapes only. Other historical volume objects/episode shapes require source parser.'},
    'NovelProjection':obj({'data':obj({'content_decrypted':{'const':True},'content':NONEMPTY},
                                      ['content_decrypted','content'],True)},['data'],True),
    'MangaProjection':{'anyOf':[obj({'images':array(NONEMPTY,minItems=1)},['images'],True),
                               obj({'content':NONEMPTY},['content'],True)]},
    'AudioProjection':obj({'data':array(obj({'item_id':S,'code':{},'main_url':S,'backup_url':S,
                                            'video_model':S},[],True))},['data'],True),
    'SeriesProjection':obj({'data':obj({'video_data':obj({'series_id_str':S,'series_title':S,
                            'series_intro':S,'series_cover':S,'episode_cnt':{},'category_schema':S},[],True)},
                                        ['video_data'],True)},['data'],True),
    'VideoProjection':obj({'video_url':NONEMPTY,'video_id':S,'key_hex':S,
        'variants':array(obj({'name':S,'width':I,'height':I,'url':NONEMPTY,'key_hex':S},[],True))},
        ['video_url'],True),
}
for name,value in fq_schemas.items():
    if name.endswith('Projection') and name != 'ChapterProjection':
        value.setdefault('properties',{}).update({'code':{'enum':[0,200]},'success':{'not':{'const':False}}})
fq_paths={}
for path, schema, params, evidence in [
    ('/api/v1/search','SearchProjection',[
        param('query',schema=NONEMPTY,required=True),param('tab_type',schema=I),
        param('offset',schema={'type':'integer','default':0}),param('count',schema=I),
        param('passback'),param('search_type')],['F04','F42']),
    ('/api/v1/books/{bookId}/detail','BookProjection',[param('bookId','path',NONEMPTY,True)],['F27','F44']),
    ('/api/v1/books/{bookId}/directory','DirectoryProjection',[param('bookId','path',NONEMPTY,True)],['F24','F46']),
    ('/api/v1/chapters/{chapterId}/novel','NovelProjection',[param('chapterId','path',NONEMPTY,True)],['F07','F09']),
    ('/api/v1/manga/{chapterId}','MangaProjection',[param('chapterId','path',NONEMPTY,True),
                                                 param('show_html',schema={'enum':['0','1']})],['F47','F41']),
    ('/api/v1/audio/books/{bookId}/chapters/{chapterId}','AudioProjection',[
        param('bookId','path',NONEMPTY,True),param('chapterId','path',NONEMPTY,True),
        param('tone_id',schema={'type':'string','default':'0'})],['F22','F31','F48']),
    ('/api/v1/series/{seriesId}','SeriesProjection',[param('seriesId','path',NONEMPTY,True)],['F19','F49']),
    ('/api/v1/videos/{videoId}','VideoProjection',[param('videoId','path',NONEMPTY,True),
        param('mode',schema={'type':'string'},description='stream 只返回播放描述；省略可能下载')],['F50','F51'])]:
    op=operation(schema,{'anyOf':[ref(schema),ref('BusinessError')]},params,evidence=evidence)
    op['description']='默认 FFI。HTTP 调试必须使用运行时基址和 capability。响应 schema 仅已知消费端投影；未知上游分支不承诺匹配。'
    op['x-source-projection-only']=True
    op['security']=[{'localCapability':[]}]
    for status in ['400','500']: op['responses'][status]=json_response(ref('RustError'),'本地 Rust 错误')
    op['responses']['401']={'description':'HTTP 访问缺少本次运行的 capability，body 不在本投影内'}
    op['responses']['403']={'description':'HTTP Host/Origin 检查失败，body 不在本投影内'}
    fq_paths[path]={'get':op}
fq=spec('fqapp 核心读取接口（源码投影）','FQ-LOCAL / source inferred',fq_schemas,fq_paths,'http://127.0.0.1:8080')
fq['components']['securitySchemes']={'localCapability':{'type':'http','scheme':'bearer',
    'description':'当前运行时 capability，仅本地 HTTP transport。FFI 不发此 header。'}}
write('fqapp-read.openapi.json',fq)


# Legado local control API. Error data may be omitted or null.
rule={'type':['object','null'],'additionalProperties':True}
source=obj({'bookSourceUrl':NONEMPTY,'bookSourceName':NONEMPTY,'bookSourceType':{'type':'integer','enum':[0,1,2,3]},
    'enabled':B,'enabledExplore':B,'header':NS,'searchUrl':NS,'ruleSearch':rule,'ruleBookInfo':rule,
    'ruleToc':rule,'ruleContent':rule},['bookSourceUrl','bookSourceName'],True)
lg_schemas={
    'BookSource':source,
    'Chapter':obj({'url':S,'title':S,'bookUrl':S,'baseUrl':S,'index':I,'isVolume':B,
                   'isVip':B,'isPay':B,'resourceUrl':NS},[],True),
    'BookProgress':obj({'name':S,'author':S,'durChapterIndex':I,'durChapterPos':I,
                        'durChapterTime':I,'durChapterTitle':NS},
                       ['name','author','durChapterIndex','durChapterPos','durChapterTime'],True),
    'Error':obj({'isSuccess':{'const':False},'errorMsg':S,'data':{}},['isSuccess','errorMsg'],True),
}
def lg_success(data):
    return obj({'isSuccess':{'const':True},'errorMsg':{'const':''},'data':data},
               ['isSuccess','errorMsg','data'],True)
for name,data in [('Saved',{'const':''}),('Source',ref('BookSource')),('Sources',array(ref('BookSource'))),
                  ('Catalog',array(ref('Chapter'))),('Text',S),('Bookshelf',array({'type':'object'}))]:
    lg_schemas[name]=lg_success(data)
lg_paths={}
for method,path,result,params,body,evidence in [
    ('post','/saveBookSource','Saved',[],ref('BookSource'),['L24']),
    ('post','/saveBookSources','Sources',[],array(ref('BookSource')),['L24']),
    ('get','/getBookSource','Source',[param('url',schema=NONEMPTY,required=True)],None,['L24']),
    ('get','/getBookSources','Sources',[],None,['L24']),
    ('get','/getBookshelf','Bookshelf',[],None,['L14']),
    ('get','/getChapterList','Catalog',[param('url',schema=NONEMPTY,required=True)],None,['L15','L25']),
    ('get','/getBookContent','Text',[param('url',schema=NONEMPTY,required=True),
                                  param('index',schema=I,required=True)],None,['L15']),
    ('post','/saveBookProgress','Saved',[],ref('BookProgress'),['L26','L27'])]:
    op=operation(result,{'anyOf':[ref(result),ref('Error')]},params,body,evidence)
    op['description']='成功与业务失败均可能 HTTP 200。普通分支 MIME 未显式保证 JSON；按预期 envelope 解码。'
    if method=='post': op['x-local-state-mutation']=True
    lg_paths[path]={method:op}
lg=spec('Legado 历史快照本地控制接口','LG-CONTROL / source inferred',lg_schemas,lg_paths,'http://127.0.0.1:1234')
lg['x-websocket-search']={'url':'ws://127.0.0.1:1235/searchBook','request':{'key':'学习'},
    'responses':'SearchBook[] JSON text batches OR plain-text error; close reason Search finish',
    'source':'L28'}
write('legado-control.openapi.json',lg)


# Every fenced JSON example must parse; retain its section and provenance.
document=(ROOT/'reports/04_API请求响应规范与排错手册.md').read_text(encoding='utf-8')
examples=[]
for match in re.finditer(r'^```json\n(.*?)^```',document,re.M|re.S):
    prefix=document[:match.start()]
    section=re.findall(r'^#{2,3} (.+)$',prefix,re.M)[-1]
    payload=json.loads(match[1])
    examples.append({'id':f'doc-json-{len(examples)+1:02d}','section':section,
        'provenance':'document example; synthetic values / fixture shape; not an upstream capture',
        'payload':payload})
write('source-examples.json',{'description':'See narrative provenance per section; no online upstream capture.',
                            'examples':examples})


# Importable Postman collection. It is not executed by this generator.
def request_item(name,method,url,body=None,capability=False):
    headers=[{'key':'Accept','value':'application/json'}]
    request={'method':method,'header':headers,'url':url,
             'description':'Template only. Configure the corresponding running local service; no request was executed.'}
    if capability: headers.append({'key':'Authorization','value':'Bearer {{fq_capability}}'})
    if body is not None:
        headers.append({'key':'Content-Type','value':'application/json; charset=utf-8'})
        request['body']={'mode':'raw','raw':json.dumps(body,ensure_ascii=False,indent=2),
                         'options':{'raw':{'language':'json'}}}
    return {'name':name,'request':request,'response':[]}

fixture_requests=[request_item(name,'GET','{{fixture_base}}'+path) for name,path in [
    ('搜索小说','/v1/search?kind=novel&query=&page=1&pageSize=10'),('小说详情','/v1/items/n1'),
    ('小说目录','/v1/items/n1/chapters'),('小说正文','/v1/chapters/n1-1/content'),
    ('漫画页表','/v1/chapters/m1-1/content'),('音频描述','/v1/chapters/a1-1/content'),
    ('视频描述','/v1/chapters/v1-1/content')]]
fq_requests=[]
for path in fq_paths:
    replaced=re.sub(r'\{(\w+)\}',lambda m:'{{fq_'+m[1]+'}}',path)
    if path.endswith('search'): replaced+='?query=demo&tab_type=3&offset=0&count=10'
    if path.endswith('{videoId}'): replaced+='?mode=stream'
    if '/audio/books/' in path: replaced+='?tone_id=0'
    fq_requests.append(request_item(path,'GET','{{fq_base}}'+replaced,capability=True))
local_source=json.loads((ROOT/'examples/legado-local-source.json').read_text(encoding='utf-8'))
lg_requests=[request_item('读取书源','GET','{{legado_base}}/getBookSources'),
    request_item('目录（bookUrl 必须 URL 编码）','GET','{{legado_base}}/getChapterList?url={{legado_bookUrlEncoded}}'),
    request_item('正文（url 仍为 bookUrl）','GET','{{legado_base}}/getBookContent?url={{legado_bookUrlEncoded}}&index=0'),
    request_item('导入单源：会修改本地配置','POST','{{legado_base}}/saveBookSource',local_source),
    request_item('导入多源：body 为数组','POST','{{legado_base}}/saveBookSources',[local_source])]
write('requests.postman_collection.json',{
    'info':{'name':'开源聚合 API 调试模板 1.1','schema':'https://schema.getpostman.com/json/collection/v2.1.0/collection.json',
        'description':'FQ/Legado source-derived templates; fixture executable locally. No upstream credentials or third-party requests.'},
    'variable':[{'key':key,'value':value,'type':'string'} for key,value in [
        ('fixture_base','http://127.0.0.1:8765'),('fq_base','http://127.0.0.1:8080'),('fq_capability',''),
        ('fq_bookId','REPLACE_WITH_BOOK_ID'),('fq_chapterId','REPLACE_WITH_CHAPTER_ID'),
        ('fq_seriesId','REPLACE_WITH_SERIES_ID'),('fq_videoId','REPLACE_WITH_VIDEO_ID'),
        ('legado_base','http://127.0.0.1:1234'),
        ('legado_bookUrlEncoded','http%3A%2F%2F127.0.0.1%3A8765%2Fv1%2Fitems%2Fn1')]],
    'item':[{'name':'FIXTURE：可运行示例','item':fixture_requests},
            {'name':'FQ-LOCAL：需运行 fqapp','item':fq_requests},
            {'name':'LG-CONTROL：需运行 Legado（含本地配置写模板）','item':lg_requests}]})
print(json.dumps({'openapi_documents':3,'document_json_examples':len(examples),
                  'postman_requests':len(fixture_requests)+len(fq_requests)+len(lg_requests)},ensure_ascii=True))
