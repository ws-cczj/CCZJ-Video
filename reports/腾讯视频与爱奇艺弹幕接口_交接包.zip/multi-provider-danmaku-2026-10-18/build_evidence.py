"""Build reproducible handoff indexes from saved evidence. No network requests."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'examples'))
from danmaku_adapter import decompress,parse_qq,parse_iqiyi
from catalog_requests import templates

def save(path,obj):
    (ROOT/path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

evidence=ROOT/'evidence'
records=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(evidence.glob('*.http.json'))]
save('evidence/probe-manifest.json',records)
stats=[]
for name,provider,episode,ext in [('qq-segment','qq','c4102g9a01t','.json'),('qq-segment-2','qq','c4102g9a01t','.json'),
                                ('iq-kb-segment','iqiyi','3493131456125200','.br'),('iq-kb-segment-2','iqiyi','3493131456125200','.br')]:
    raw=decompress(evidence/(name+ext));d=parse_qq(raw,episode) if provider=='qq' else parse_iqiyi(raw,episode)
    save('evidence/'+name+'-normalized.json',d)
    stats.append(dict(name=name,provider=provider,episodeId=episode,count=len(d['items']),
                      minTimeMs=min(x['timeMs'] for x in d['items']),maxTimeMs=max(x['timeMs'] for x in d['items']),
                      warnings=d['warnings'],decompressedBytes=len(raw)))
save('evidence/verification.json',dict(generatedUtc=datetime.now(timezone.utc).isoformat(),
     httpProbeCount=len(records),httpSuccessCount=sum(r.get('status')==200 for r in records),
     segmentDecodeResults=stats,offlineTests=15,
     limits=['Only two segments per successful episode were read. No full-library or full-episode completeness claim.',
             'No cookies, authenticated playback, media downloads, DRM, or APK evidence in this study.']))
save('api/request-templates.json',templates())

samples={}
for name in ['qq-title-search','qq-episodes','qq-base','qq-segment','iq-search','iq-episodes','iq-decode','iq-kb-baseinfo']:
    samples[name]=dict(response_file='../evidence/'+name+'.json',http_record='../evidence/'+name+'.http.json')
save('api/response-index.json',samples)

qqsearch=json.loads((evidence/'qq-title-search.json').read_bytes())
qqitem=next(x for x in qqsearch['data']['normalList']['itemList'] if x.get('doc',{}).get('id')=='mzc00200803dr6b')
iqsearch=json.loads((evidence/'iq-search.json').read_bytes())
iqalbum=next(x['albumInfo'] for x in iqsearch['data']['templates'] if x.get('albumInfo',{}).get('title')=='狂飙')
iqdetail=json.loads((evidence/'iq-episodes.json').read_bytes())
iqeps=[]
for tab in iqdetail['data']['template']['tabs']:
    for block in tab.get('blocks',[]):
        if block.get('bk_type')=='album_episodes':
            for group in block['data']['data']:
                videos=group.get('videos')
                if isinstance(videos,dict):
                    for rows in (videos.get('feature_paged') or {}).values():
                        iqeps.extend(x for x in rows if x.get('content_type')==1)
save('evidence/binding-verification.json',dict(
    qq=dict(title=qqitem['videoInfo']['title'],cid=qqitem['doc']['id'],providerSites=[s['enName'] for s in qqitem['videoInfo']['playSites']],
            episodeVid='c4102g9a01t',episodePage='https://v.qq.com/x/cover/mzc00200803dr6b/c4102g9a01t.html'),
    iqiyi=dict(title=iqalbum['title'],albumId=str(iqalbum['qipuId']),firstTVid=str(iqalbum['playQipuId']),
               firstPage=iqalbum['pageUrl'],detailFeatureEpisodes=len({str(x['qipu_id']) for x in iqeps}),
               searchEmbeddedVideos=len(iqalbum.get('videos',[]))),
    crossProviderPitfall='Tencent search for 狂飙 returns an external qiyi site item; its doc.id must not be passed to Tencent barrage APIs.'))
print(json.dumps({'records':len(records),'stats':stats,'iqiyiFeatureEpisodes':len({str(x['qipu_id']) for x in iqeps})},ensure_ascii=False,indent=2))
