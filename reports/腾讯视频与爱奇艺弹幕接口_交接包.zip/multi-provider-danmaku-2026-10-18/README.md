# 腾讯视频、爱奇艺弹幕开发交接

先读 [腾讯视频与爱奇艺弹幕接口_开发交接.md](腾讯视频与爱奇艺弹幕接口_开发交接.md)。

- `api/request-templates.json`：9 类完整请求样例，包括 POST JSON 请求体；爱奇艺详情签名带时间戳，使用前重新生成。
- `api/upstream-observed.openapi.json`：观察到的 HTTP 请求/响应结构，属于开发参考，不是平台承诺的开放 API 规范。
- `api/iqiyi_danmaku_observed.proto`：爱奇艺二进制弹幕的已识别字段子集。
- `evidence/*.http.json`：实际请求、响应状态/头、文件大小、SHA256；不包含登录凭证。
- `evidence/verification.json`、`binding-verification.json`：解析统计与标题绑定证据。
- `examples/danmaku_adapter.py`：QQ JSON、爱奇艺 Brotli/Protobuf/XML 归一化解析。
- `examples/catalog_requests.py`：元数据请求模板；生成当前时间戳的爱奇艺详情 URL。
- `reference/*-source.zip`：两份固定 commit 源码与原始许可证，未执行它们的程序。

Python 3.10+；解析 `.br` 另需可从 PATH 调用的 Node.js（本次验证 Node 24.19.0、Python 本机环境）。

```powershell
# 在本交接包目录内执行；均为离线解析，不请求平台。
python examples/danmaku_adapter.py qq evidence/qq-segment.json c4102g9a01t --output qq-demo.json
python examples/danmaku_adapter.py iqiyi evidence/iq-kb-segment.br 3493131456125200 --output iqiyi-demo.json
python -m unittest discover -s examples -p test_adapter.py -v
python api/check_contracts.py
```

15 项离线测试通过；实际各读取两段弹幕，不代表整集或全库完整。网络访问单独放在 `probe_public_read.py`，不会在解析或测试时自动运行。该脚本是初次 6 次公开读取的复现入口；追加请求已逐条保存在 evidence，整次研究总共 15 次 HTTP 请求。需要重放其他请求时，先确认目标，再使用请求模板；不要将签名过期、风控、404 混同为“零弹幕”。

这个目录补充上一份 B 站文档；三个平台的 ID 不能混用。当前未修改用户的软件仓库，也未做腾讯/爱奇艺 APK 分析。
