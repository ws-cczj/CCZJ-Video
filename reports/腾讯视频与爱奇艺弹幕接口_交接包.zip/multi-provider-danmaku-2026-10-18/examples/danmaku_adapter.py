"""Independent read/normalization example. Python 3.10+; .br also needs Node.js.

Input: saved QQ JSON or iQiyi .br/.z/decompressed XML/Protobuf. No HTTP or playback.
Usage: python danmaku_adapter.py qq FILE VID --output output.json
       python danmaku_adapter.py iqiyi FILE NUMERIC_TVID --output output.json
IDs stay strings; timeMs is global video time; unknown visual effects are not recreated.
"""
import argparse
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zlib

MAX_INPUT = 8 * 1024 * 1024
MAX_PAYLOAD = 32 * 1024 * 1024

class ProtocolError(ValueError):
    pass

def number(value, scale=1):
    try:
        x = Decimal(str(value)) * scale
        if not x.is_finite() or x < 0: raise ProtocolError('invalid nonnegative time/count')
        return int(x.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    except (InvalidOperation, TypeError, ValueError) as error:
        raise ProtocolError(f'invalid numeric value: {value!r}') from error

def rgb(value):
    text = str(value or '').removeprefix('#')
    return int(text, 16) if re.fullmatch(r'[0-9a-fA-F]{6}', text) else 0xffffff

def item(provider, episode, ident, time_ms, text, color=0xffffff, mode=1, likes=0, fmt=''):
    if not isinstance(text, str) or not text: raise ProtocolError('missing text')
    return dict(provider=provider, sourceEpisodeId=str(episode), id=None if ident is None else str(ident),
                timeMs=time_ms, text=text, mode=mode, color=color, fontSize=25,
                likes=likes, sourceFormat=fmt)

def envelope(items, warnings):
    items.sort(key=lambda x:x['timeMs'])
    return dict(status='ok' if items else 'empty', items=items, warnings=warnings)

def parse_qq(raw, vid):
    data=json.loads(raw)
    if not isinstance(data,dict) or not isinstance(data.get('barrage_list'),list):
        raise ProtocolError('QQ schema mismatch: barrage_list must be an array')
    rows=[]; warnings=[]
    for index, entry in enumerate(data['barrage_list']):
        try:
            style={}
            if entry.get('content_style'):
                try:
                    style=json.loads(entry['content_style'])
                    if not isinstance(style,dict): raise ValueError('style is not an object')
                except (ValueError,TypeError):
                    style={}; warnings.append(f'row {index}: invalid content_style; default appearance')
            gradient=style.get('gradient_colors')
            color=gradient[0] if isinstance(gradient,list) and gradient else style.get('color')
            rows.append(item('qq',vid,entry.get('id'),number(entry['time_offset']),entry['content'],
                             rgb(color),{2:5,3:4}.get(style.get('position'),1),
                             number(entry.get('up_count',0)), 'json'))
        except (ProtocolError,KeyError,TypeError,AttributeError) as error:
            warnings.append(f'row {index}: rejected: {error}')
    if data['barrage_list'] and not rows: raise ProtocolError('all QQ rows invalid')
    return envelope(rows,warnings)

def read_varint(raw, start):
    value=0
    for i in range(10):
        pos=start+i
        if pos >= len(raw): raise ProtocolError('truncated protobuf varint')
        b=raw[pos]
        if i==9 and b>1: raise ProtocolError('protobuf uint64 overflow')
        value |= (b & 127) << (i*7)
        if b<128:return value,pos+1
    raise ProtocolError('protobuf varint too long')

def fields(raw):
    pos=0; result=[]
    while pos<len(raw):
        key,pos=read_varint(raw,pos)
        if key==0:
            if any(raw[pos:]): raise ProtocolError('nonzero bytes after protobuf padding')
            break
        tag,wire=key>>3,key&7
        if not tag or tag >= 2**29: raise ProtocolError('invalid protobuf field number')
        if wire==0:
            value,pos=read_varint(raw,pos)
        elif wire==2:
            length,pos=read_varint(raw,pos); end=pos+length
            if end>len(raw):raise ProtocolError('truncated protobuf bytes')
            value=raw[pos:end];pos=end
        elif wire in (1,5):
            end=pos+(8 if wire==1 else 4)
            if end>len(raw):raise ProtocolError('truncated protobuf fixed value')
            value=raw[pos:end];pos=end
        else:raise ProtocolError(f'unsupported protobuf wire type {wire}')
        result.append((tag,wire,value))
    return result

def string(fs,tag,default=''):
    for n,w,v in fs:
        if n==tag:
            if w==2:
                try:return v.decode('utf-8')
                except UnicodeDecodeError as error:raise ProtocolError('invalid protobuf UTF-8') from error
            if w==0:return str(v)
    return default

def parse_iqiyi_proto(raw,tvid):
    root=fields(raw); code=string(root,1)
    if code and code!='A00000':raise ProtocolError(f'iQiyi payload business code: {code}')
    blocks=[v for n,w,v in root if n==6 and w==2]
    if not code and not blocks:raise ProtocolError('unrecognized iQiyi protobuf schema')
    rows=[];warnings=[]
    for block in blocks:
        bf=fields(block); block_time=string(bf,1,'0')
        for n,w,v in bf:
            if n!=2 or w!=2:continue
            ef=fields(v)
            try:
                rows.append(item('iqiyi',tvid,string(ef,1) or None,
                    number(string(ef,6,block_time),1000),html.unescape(string(ef,2)),
                    rgb(string(ef,8)),1,number(string(ef,14,'0')),'protobuf'))
            except ProtocolError as error:warnings.append(f'item rejected: {error}')
    if blocks and not rows and warnings:raise ProtocolError('all iQiyi rows invalid')
    return envelope(rows,warnings)

def parse_iqiyi_xml(raw,tvid):
    if re.search(rb'<!\s*(DOCTYPE|ENTITY)',raw,re.I):raise ProtocolError('DTD/entity declarations rejected')
    try:root=ET.fromstring(raw)
    except ET.ParseError as error:raise ProtocolError('invalid XML') from error
    if root.tag.rsplit('}',1)[-1]!='danmu':raise ProtocolError('unrecognized iQiyi XML root')
    rows=[];warnings=[]
    for node in root.iter():
        if node.tag.rsplit('}',1)[-1]!='bulletInfo':continue
        values={child.tag.rsplit('}',1)[-1]:''.join(child.itertext()) for child in node}
        try:
            rows.append(item('iqiyi',tvid,values.get('contentId') or None,
                        number(values['showTime'],1000),values['content'],rgb(values.get('color')),
                        1,number(values.get('likeCount',0)),'xml'))
        except (ProtocolError,KeyError) as error:warnings.append(f'item rejected: {error}')
    if not rows and warnings:raise ProtocolError('all iQiyi XML rows invalid')
    return envelope(rows,warnings)

def decompress(path):
    path=Path(path)
    if path.stat().st_size>MAX_INPUT:raise ProtocolError('input exceeds 8 MiB')
    raw=path.read_bytes()
    if path.suffix=='.br':
        node=shutil.which('node')
        if not node:raise ProtocolError('Node.js required for Brotli: node not found')
        reply=subprocess.run([node,str(Path(__file__).with_name('brotli_decode.cjs')),str(path)],
                             capture_output=True,timeout=15)
        if reply.returncode:raise ProtocolError('Brotli failed: '+reply.stderr.decode('utf-8',errors='replace')[:500])
        raw=reply.stdout
    elif path.suffix=='.z':
        decoder=zlib.decompressobj()
        raw=decoder.decompress(raw,MAX_PAYLOAD+1)
        if len(raw)>MAX_PAYLOAD or decoder.unconsumed_tail:raise ProtocolError('inflated data too large')
        if not decoder.eof:raise ProtocolError('truncated zlib stream')
        if decoder.unused_data:raise ProtocolError('extra data after zlib stream')
    if len(raw)>MAX_PAYLOAD:raise ProtocolError('payload exceeds 32 MiB')
    return raw

def parse_iqiyi(raw,tvid):
    trimmed=raw.removeprefix(b'\xef\xbb\xbf').lstrip()
    if trimmed.startswith(b'<'):return parse_iqiyi_xml(trimmed,tvid)
    return parse_iqiyi_proto(raw,tvid)

def iqiyi_segment_url(tvid,page):
    if not re.fullmatch(r'\d+',tvid) or not isinstance(page,int) or isinstance(page,bool) or page<1:
        raise ProtocolError('numeric TVid and one-based page required')
    padded=tvid.zfill(4); sign=hashlib.md5(f'{tvid}_60_{page}cbzuw1259a'.encode()).hexdigest()[-8:]
    return f'https://cmts.iqiyi.com/bullet/{padded[-4:-2]}/{padded[-2:]}/{tvid}_60_{page}_{sign}.br'

def qq_segment_urls(raw,vid):
    data=json.loads(raw)
    if not isinstance(data,dict) or not isinstance(data.get('segment_index'),dict):
        raise ProtocolError('QQ schema mismatch: segment_index must be an object')
    items=[]
    for v in data['segment_index'].values():
        name=v['segment_name']
        if not re.fullmatch(r'[A-Za-z0-9/_-]+',name):raise ProtocolError('invalid QQ segment path')
        items.append(dict(startMs=number(v['segment_start']),
                          url=f'https://dm.video.qq.com/barrage/segment/{vid}/{name}'))
    return sorted(items,key=lambda x:x['startMs'])

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('provider',choices=['qq','iqiyi']);parser.add_argument('file',type=Path)
    parser.add_argument('episode_id');parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        raw=decompress(args.file)
        result=parse_qq(raw,args.episode_id) if args.provider=='qq' else parse_iqiyi(raw,args.episode_id)
        encoded=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
        if args.output:args.output.write_text(encoded,encoding='utf-8')
        else:print(encoded,end='')
    except (ProtocolError,ValueError,OSError,subprocess.SubprocessError) as error:
        print(json.dumps(dict(status='parse_failed',error=str(error)),ensure_ascii=False),file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':sys.exit(main())
