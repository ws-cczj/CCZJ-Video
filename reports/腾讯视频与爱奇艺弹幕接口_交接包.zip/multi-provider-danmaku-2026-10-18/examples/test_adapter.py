"""Offline protocol regressions. No upstream requests."""
import json
from pathlib import Path
import unittest
import zlib
from danmaku_adapter import (parse_qq, parse_iqiyi, fields, ProtocolError, iqiyi_segment_url,
                             qq_segment_urls, number, decompress)

def varint(n):
    out=bytearray()
    while n>=128:out.append((n&127)|128);n>>=7
    out.append(n);return bytes(out)

def msg(tag,value):
    value=value.encode() if isinstance(value,str) else value
    return varint(tag*8+2)+varint(len(value))+value

class AdapterTests(unittest.TestCase):
    def test_qq_ms_and_large_id(self):
        d=parse_qq(b'{"barrage_list":[{"id":9007199254740993,"time_offset":"30001","content":"x"}]}','v')
        self.assertEqual((d['items'][0]['id'],d['items'][0]['timeMs']),('9007199254740993',30001))

    def test_qq_style(self):
        d=parse_qq(json.dumps({'barrage_list':[{'time_offset':0,'content':'x','content_style':json.dumps({'position':2,'color':'#ff0000'})}]}),'v')
        self.assertEqual((d['items'][0]['mode'],d['items'][0]['color']),(5,0xff0000))

    def test_schema_is_not_empty(self):
        with self.assertRaises(ProtocolError):parse_qq(b'{"error":"denied"}','v')

    def test_empty(self):
        self.assertEqual(parse_qq(b'{"barrage_list":[]}','v')['status'],'empty')

    def test_proto_global_seconds_unknown_field_and_large_id(self):
        entry=msg(1,'1707482806092036748')+msg(2,'a &amp; b')+msg(6,'61.25')+msg(8,'ff0000')+msg(14,'2')
        raw=msg(1,'A00000')+msg(99,'new field')+msg(6,msg(1,'60')+msg(2,entry))+b'\x00'
        row=parse_iqiyi(raw,'1')['items'][0]
        self.assertEqual((row['id'],row['timeMs'],row['text'],row['likes']),('1707482806092036748',61250,'a & b',2))

    def test_proto_time_fallback(self):
        raw=msg(6,msg(1,'60.5')+msg(2,msg(2,'x')))
        self.assertEqual(parse_iqiyi(raw,'1')['items'][0]['timeMs'],60500)

    def test_proto_truncation(self):
        for raw in [b'\x32\x80',b'\x32\x05ab',b'\x09a',b'\x0d',b'\x08'+b'\xff'*10]:
            with self.subTest(raw=raw),self.assertRaises(ProtocolError):fields(raw)

    def test_proto_business_error(self):
        with self.assertRaises(ProtocolError):parse_iqiyi(msg(1,'A00001'),'1')

    def test_proto_unknown_schema(self):
        with self.assertRaises(ProtocolError):parse_iqiyi(msg(99,'x'),'1')

    def test_xml_item_scope_entities_and_cdata(self):
        xml=b'<danmu><bulletInfo><content>a &amp; b</content><showTime>1.25</showTime></bulletInfo><bulletInfo><content><![CDATA[<x>]]></content><showTime>61</showTime><color>000000</color></bulletInfo></danmu>'
        rows=parse_iqiyi(xml,'1')['items']
        self.assertEqual([(x['timeMs'],x['text']) for x in rows],[(1250,'a & b'),(61000,'<x>')])
        self.assertEqual(rows[1]['color'],0)

    def test_xml_reject_dtd(self):
        with self.assertRaises(ProtocolError):parse_iqiyi(b'<!DOCTYPE danmu><danmu/>','1')

    def test_bad_numbers(self):
        for v in ['nan','Infinity',-1,True]:
            with self.subTest(v=v),self.assertRaises(ProtocolError):number(v)

    def test_iqiyi_url_and_page(self):
        self.assertEqual(iqiyi_segment_url('1078946400',1),'https://cmts.iqiyi.com/bullet/64/00/1078946400_60_1_fc5e9d5c.br')
        with self.assertRaises(ProtocolError):iqiyi_segment_url('1078946400',0)

    def test_qq_index_sort_and_no_fixed_path(self):
        rows=qq_segment_urls(json.dumps({'segment_index':{'b':{'segment_start':'60000','segment_name':'x/v7/60000/90000'},'a':{'segment_start':'0','segment_name':'x/v7/0/30000'}}}),'v')
        self.assertEqual([r['startMs'] for r in rows],[0,60000])
        self.assertIn('/x/v7/',rows[0]['url'])

    def test_real_saved_segments(self):
        p=Path(__file__).resolve().parents[1]/'evidence'
        qq=parse_qq((p/'qq-segment.json').read_bytes(),'c4102g9a01t')
        qq_second=parse_qq((p/'qq-segment-2.json').read_bytes(),'c4102g9a01t')
        iq=parse_iqiyi(decompress(p/'iq-kb-segment.br'),'3493131456125200')
        self.assertEqual(len(qq['items']),600)
        self.assertEqual(len(qq_second['items']),600)
        self.assertEqual(min(x['timeMs'] for x in qq_second['items']),30000)
        self.assertEqual(len(iq['items']),366)
        self.assertEqual(qq['warnings'],[]);self.assertEqual(iq['warnings'],[])
        second=parse_iqiyi(decompress(p/'iq-kb-segment-2.br'),'3493131456125200')
        self.assertEqual(len(second['items']),399)
        self.assertGreaterEqual(min(x['timeMs'] for x in second['items']),60000)

if __name__=='__main__':unittest.main()
