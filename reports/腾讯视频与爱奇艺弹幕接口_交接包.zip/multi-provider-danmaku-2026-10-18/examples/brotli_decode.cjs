// Node.js built-in Brotli decoder. Reads a local file; performs no network requests.
const fs = require('node:fs');
const zlib = require('node:zlib');
const raw = fs.readFileSync(process.argv[2]);
if (raw.length > 8 * 1024 * 1024) throw new Error('compressed input exceeds 8 MiB');
process.stdout.write(zlib.brotliDecompressSync(raw, { maxOutputLength: 32 * 1024 * 1024 }));
