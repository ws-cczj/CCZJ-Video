"""Build metadata requests with current timestamps. No networking or credentials.
Run: python catalog_requests.py > ../api/request-templates.json
"""
import hashlib
import json
from pathlib import Path
import sys
import time
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

ROOT=Path(__file__).resolve().parents[1]

def iqiyi_detail_url(entity_id, device_id='protocol-study-local', timestamp_ms=None):
    params=dict(entity_id=str(entity_id),device_id=device_id,auth_cookie='',user_id='0',vip_type='-1',
                vip_status='0',conduit_id='',pcv='13.082.22866',app_version='13.082.22866',ext='',
                app_mode='standard',scale='100',timestamp=str(timestamp_ms or int(time.time()*1000)),
                src='pca_tvg',os='',ad_ext='{"r":"2.2.0-ares6-pure"}')
    # Hash raw values before URL encoding. This is a public client-format checksum,
    # not user authentication, VIP permission, or a media decryption key.
    canonical='&'.join(k+'='+v for k,v in sorted(params.items()))+'&secret_key=howcuteitis'
    params['sign']=hashlib.md5(canonical.encode('utf-8')).hexdigest().upper()
    return 'https://www.iqiyi.com/prelw/tvg/v2/lw/base_info?'+urlencode(params)

def replace_query(url, **values):
    parts=urlsplit(url); q=dict(parse_qsl(parts.query,keep_blank_values=True));q.update(values)
    return urlunsplit((parts.scheme,parts.netloc,parts.path,urlencode(q),parts.fragment))

def templates():
    requests=[]
    for name in ['qq-title-search','qq-episodes','qq-base','qq-segment','iq-search','iq-episodes','iq-decode','iq-kb-baseinfo','iq-kb-segment']:
        data=json.loads((ROOT/'evidence'/(name+'.http.json')).read_text(encoding='utf-8'))
        row={k:data[k] for k in ['name','method','url','request_headers','request_body']}
        if name=='iq-episodes': row['url']=iqiyi_detail_url('3493131456125200')
        requests.append(row)
    return dict(description='Observed public requests; availability is not an official API guarantee. Rebuild signed detail URL before use.',requests=requests)

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    print(json.dumps(templates(),ensure_ascii=False,indent=2))
