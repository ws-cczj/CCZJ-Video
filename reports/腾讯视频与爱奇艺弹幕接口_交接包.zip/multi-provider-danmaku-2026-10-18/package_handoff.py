"""Package this study, including fixed source archives, excluding extracted duplicates."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT.parent/'腾讯视频与爱奇艺弹幕接口_交接包.zip'
EXCLUDE={'qq-normalized.json','iq-kb-normalized.json','iq-kb-segment.decompressed.bin'}

def included(path):
    rel=path.relative_to(ROOT)
    if '__pycache__' in rel.parts or path.suffix=='.pyc':return False
    if path.name in EXCLUDE or path.name=='package-manifest.json':return False
    if rel.parts[0]=='reference':return path.parent==ROOT/'reference' and path.suffix=='.zip'
    return True

paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and included(p))
manifest={'generatedUtc':datetime.now(timezone.utc).isoformat(),
          'note':'Manifest lists all package files except this manifest itself; reference trees are supplied as fixed source ZIPs.',
          'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,
                    'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
manifest_path=ROOT/'package-manifest.json'
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUTPUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in paths+[manifest_path]:archive.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    for row in manifest['files']:
        raw=archive.read(ROOT.name+'/'+row['path'])
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
print(json.dumps({'file':str(OUTPUT),'bytes':OUTPUT.stat().st_size,'files':len(paths)+1,
                  'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest()},ensure_ascii=False))
