"""Build an observed OpenAPI reference from evidence. No network requests."""
import json
from pathlib import Path
from urllib.parse import parse_qsl,urlsplit
ROOT=Path(__file__).resolve().parents[1]
T=json.loads((ROOT/'api/request-templates.json').read_text(encoding='utf-8'))['requests']

def ref(n):return {'$ref':'#/components/schemas/'+n}
def obj(props):return {'type':'object','properties':props,'additionalProperties':True}
def arr(schema):return {'type':'array','items':schema}
def text(desc=''):return {'type':'string',**({'description':desc} if desc else {})}
def observed_schema(v):
    if isinstance(v,bool):return {'type':'boolean'}
    if isinstance(v,int):return {'type':'integer'}
    if isinstance(v,float):return {'type':'number'}
    if isinstance(v,str):return text()
    if isinstance(v,dict):return obj({k:observed_schema(x) for k,x in v.items()})
    if isinstance(v,list):return arr(observed_schema(v[0]) if v else {})
    return {}

numeric={'oneOf':[{'type':'integer','minimum':0},{'type':'string','pattern':'^[0-9]+$'}]}
schemas={
 'TencentSegmentIndexItem':obj({'segment_start':{**numeric,'description':'Global start, milliseconds'},'segment_name':text('Use this returned path verbatim after the vid; do not hardcode t/v1')}),
 'TencentBase':obj({'total':numeric,'count_to_display':numeric,'segment_span':numeric,'segment_start':numeric,'first_segment':arr({}),
                   'segment_index':{'type':'object','additionalProperties':ref('TencentSegmentIndexItem')}}),
 'TencentBullet':obj({'id':text('Opaque ID, retain as string'),'time_offset':{**numeric,'description':'Global video milliseconds, NOT segment-relative'},
      'content':text(),'content_style':text('Empty or JSON-encoded string, parse once more'),
      'up_count':numeric,'create_time':numeric}),
 'TencentSegment':{**obj({'barrage_list':arr(ref('TencentBullet'))}),'required':['barrage_list']},
 'TencentSearchResponse':obj({'ret':{'type':'integer'},'msg':text(),'data':obj({
      'normalList':obj({'itemList':arr(obj({'doc':obj({'id':text('Cover/series CID, not episode VID')}),'videoInfo':{**obj({
          'title':text(),'year':{'type':'integer'},'playSites':arr(obj({'enName':text()}))}),'type':['object','null']}}))}),
      'areaBoxList':arr(obj({'boxId':text(),'itemList':arr(obj({}))}))})}),
 'TencentEpisodesResponse':obj({'ret':{'type':'integer'},'data':obj({'module_list_datas':arr(obj({'module_datas':arr(obj({
      'module_params':obj({'tabs':text('JSON string; extract each page_context to request subsequent pages'),'has_next':{'type':['boolean','string']}}),
      'item_data_lists':obj({'item_datas':arr(obj({'item_params':obj({'vid':text(),'cid':text(),'is_trailer':text(),'title':text(),
          'play_title':text(),'union_title':text(),'video_subtitle':text(),'c_title_output':text(),'duration':numeric})}))})}))}))})}),
 'IqiyiDecode':obj({'code':text('Observed success: 0'),'data':{'oneOf':[{'type':'integer'},text()],
      'description':'Numeric TVid; use an integer-preserving JSON parser'}}),
 'IqiyiBaseInfo':obj({'code':text('Observed success: A00000'),'data':obj({'tvId':numeric,'albumId':numeric,'name':text(),
      'playUrl':text(),'durationSec':{'type':'number'},'displayBarrage':{'type':'boolean'},'order':{'type':'integer'}})}),
 'IqiyiSearchResponse':obj({'code':{'type':['string','integer']},'data':obj({'templates':arr(obj({'template':{'type':'integer'},
      'albumInfo':obj({'title':text(),'qipuId':numeric,'playQipuId':numeric,'pageUrl':text(),'siteId':text(),
                      'videos':arr(obj({'qipuId':numeric,'playUrl':text(),'pageUrl':text(),'number':text(),'duration':numeric}))}),
      'intentAlbumInfos':arr(obj({}))}))})}),
 'IqiyiEpisodesResponse':obj({'status_code':{'type':'integer'},'msg':text(),'data':obj({'template':obj({'tabs':arr(obj({'blocks':arr(obj({
      'bk_type':text('Observed album_episodes; another supported branch is video_list'),'tag':arr(text()),'data':obj({'data':{
          'type':['array','object','string','null'],'description':'Heterogeneous blocks, including non-episode advertising blocks; dispatch by bk_type before interpreting this field'}})}))}))})})}),
 'NormalizedBullet':{**obj({'provider':{'enum':['qq','iqiyi','bili']},'sourceEpisodeId':text(),'id':{'type':['string','null']},
      'timeMs':{'type':'integer','minimum':0,'description':'Global video time in milliseconds'},'text':text(),
      'mode':{'enum':[1,4,5]},'color':{'type':'integer','minimum':0,'maximum':16777215},'fontSize':{'type':'integer'},
      'likes':{'type':'integer','minimum':0},'sourceFormat':text()}),
      'required':['provider','sourceEpisodeId','id','timeMs','text','mode','color','fontSize','likes','sourceFormat']}
}

mapping={
 'qq-title-search':('/trpc.videosearch.mobile_search.MultiTerminalSearch/MbSearch','TencentSearchResponse','POST title search; ret=0; filter external sites'),
 'qq-episodes':('/trpc.universal_backend_service.page_server_rpc.PageServer/GetPageData','TencentEpisodesResponse','POST episode selector; tabs contains a JSON string; page_context is opaque'),
 'qq-base':('/barrage/base/{vid}','TencentBase','GET segment index; observed total=0 does NOT imply an empty episode'),
 'qq-segment':('/barrage/segment/{vid}/{segmentName}','TencentSegment','GET JSON; segmentName is a multi-component path from index; NOT percent-encode the whole slash-containing string'),
 'iq-search':('/portal/lw/search/homePageV3','IqiyiSearchResponse','GET title search; observed success code=0'),
 'iq-episodes':('/prelw/tvg/v2/lw/base_info','IqiyiEpisodesResponse','GET episode selector; recalculate sorted-parameter MD5 and timestamp before use'),
 'iq-decode':('/api/decode/{pageId}','IqiyiDecode','GET public page ID to numeric TVid conversion; skip if numeric TVid already known'),
 'iq-kb-baseinfo':('/video/video/baseinfo/{tvid}','IqiyiBaseInfo','GET numeric TVid metadata; check business code and displayBarrage'),
 'iq-kb-segment':('/bullet/{dir1}/{dir2}/{tvid}_60_{page}_{checksum}.br',None,'GET file-level Brotli payload; after one file decompression, inspect XML vs Protobuf; page is one-based')
}
path_params={
 'qq-base':['vid'],'qq-segment':['vid','segmentName'],'iq-decode':['pageId'],'iq-kb-baseinfo':['tvid'],
 'iq-kb-segment':['dir1','dir2','tvid','page','checksum']}
paths={}
for template in T:
    name=template['name'];path,schema,desc=mapping[name];url=urlsplit(template['url']);method=template['method'].lower()
    params=[{'name':k,'in':'path','required':True,'schema':text()} for k in path_params.get(name,[])]
    params.extend({'name':k,'in':'query','schema':text(),'example':v} for k,v in parse_qsl(url.query,keep_blank_values=True))
    response={'description':'Observed success shape; unknown fields preserved; examples are not an exhaustive platform contract',
              'content':{'application/json':{'schema':ref(schema)}}} if schema else {
              'description':'Brotli-compressed XML or Protobuf bytes. May have no HTTP Content-Encoding.',
              'content':{'application/octet-stream':{'schema':{'type':'string','format':'binary'}}}}
    operation={'operationId':name.replace('-','_'),'summary':desc,'servers':[{'url':url.scheme+'://'+url.netloc}],
               'parameters':params,'responses':{'200':response,'404':{'description':'Not found; distinguish from valid empty payload'},
               '403':{'description':'Denied; not zero comments'},'429':{'description':'Rate limit; back off'}},
               'x-observed-http-record':'../evidence/'+name+'.http.json','x-response-body-file':
               '../evidence/'+name+('.br' if name=='iq-kb-segment' else '.json')}
    if template['request_body'] is not None:
        operation['requestBody']={'required':True,'content':{'application/json':{
            'schema':observed_schema(template['request_body']),'example':template['request_body']}}}
    paths.setdefault(path,{})[method]=operation

doc={'openapi':'3.1.0','info':{'title':'Tencent Video / iQiyi observed danmaku reads','version':'2026-10-18',
    'description':'Community implementation + bounded HTTP observations. Not an official supported open API; field requiredness beyond parser necessities is unverified. Empty body on all GET requests. No login credentials or media playback endpoints included.'},
    'paths':paths,'components':{'schemas':schemas}}
(ROOT/'api/upstream-observed.openapi.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'api/normalized-danmaku.schema.json').write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema',
    'title':'NormalizedDanmaku',**schemas['NormalizedBullet']},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Built 9 observed operations and normalization schema')
