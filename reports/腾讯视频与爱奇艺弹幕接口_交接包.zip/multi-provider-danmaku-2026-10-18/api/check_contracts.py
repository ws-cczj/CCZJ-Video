"""Check the JSON Schema subset emitted by build_contracts against saved examples.

This is a bounded structural check, not a full OpenAPI/JSON Schema validator.
It covers $ref, type, required, properties, items, oneOf, enum, range, and pattern.
"""
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
doc=json.loads((ROOT/'api/upstream-observed.openapi.json').read_text(encoding='utf-8'))

def valid_type(kind,value):
    if kind=='object':return isinstance(value,dict)
    if kind=='array':return isinstance(value,list)
    if kind=='string':return isinstance(value,str)
    if kind=='integer':return isinstance(value,int) and not isinstance(value,bool)
    if kind=='number':return isinstance(value,(int,float)) and not isinstance(value,bool)
    if kind=='boolean':return isinstance(value,bool)
    if kind=='null':return value is None
    raise ValueError('unsupported schema type '+kind)

def check(schema,value,path='$'):
    if '$ref' in schema:
        target=doc
        for part in schema['$ref'].removeprefix('#/').split('/'):target=target[part]
        return check(target,value,path)
    if 'oneOf' in schema:
        count=0
        for child in schema['oneOf']:
            try:check(child,value,path);count+=1
            except AssertionError:pass
        assert count==1,(path,'oneOf',count,value)
    if 'type' in schema:
        kinds=schema['type'] if isinstance(schema['type'],list) else [schema['type']]
        assert any(valid_type(k,value) for k in kinds),(path,'type',kinds,type(value).__name__)
    if 'enum' in schema:assert value in schema['enum'],(path,'enum',value)
    if 'minimum' in schema:assert value>=schema['minimum'],(path,'minimum')
    if 'maximum' in schema:assert value<=schema['maximum'],(path,'maximum')
    if 'pattern' in schema:assert re.search(schema['pattern'],value),(path,'pattern')
    if isinstance(value,dict):
        for key in schema.get('required',[]):assert key in value,(path,'required',key)
        props=schema.get('properties',{})
        for key,val in value.items():
            if key in props:check(props[key],val,path+'.'+key)
            elif isinstance(schema.get('additionalProperties'),dict):check(schema['additionalProperties'],val,path+'.'+key)
    if isinstance(value,list) and 'items' in schema:
        for i,val in enumerate(value):check(schema['items'],val,path+f'[{i}]')

count=0
for path,methods in doc['paths'].items():
    for method,operation in methods.items():
        if 'requestBody' in operation:
            body=operation['requestBody']['content']['application/json']
            check(body['schema'],body['example']);count+=1
        for param in operation.get('parameters',[]):
            if param['in']=='path':assert '{'+param['name']+'}' in path
        reply=operation['responses']['200']['content']
        if 'application/json' in reply:
            data=json.loads((ROOT/'api'/operation['x-response-body-file']).read_bytes())
            check(reply['application/json']['schema'],data);count+=1
for name in ['qq-segment-normalized','qq-segment-2-normalized','iq-kb-segment-normalized','iq-kb-segment-2-normalized']:
    data=json.loads((ROOT/'evidence'/(name+'.json')).read_bytes())
    for row in data['items']:check(doc['components']['schemas']['NormalizedBullet'],row)
    count+=1
print(f'Passed {count} fixture/schema checks; this is not a full standards validator.')
