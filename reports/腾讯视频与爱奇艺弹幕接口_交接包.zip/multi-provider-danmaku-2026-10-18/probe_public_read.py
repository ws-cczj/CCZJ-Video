"""Bounded public metadata/danmaku probes. No login, playback media, or batch download."""
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
LIMIT = 8 * 1024 * 1024

def probe(name, url, payload=None, headers=None, suffix='.json'):
    hdr = {'User-Agent': UA, 'Accept': '*/*', 'Accept-Encoding': 'identity'}
    hdr.update(headers or {})
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
    if body is not None: hdr['Content-Type'] = 'application/json'
    record = {'name': name, 'time_utc': datetime.now(timezone.utc).isoformat(),
              'method': 'GET' if body is None else 'POST', 'url': url,
              'request_headers': hdr, 'request_body': payload}
    try:
        try: reply = urlopen(Request(url, data=body, headers=hdr), timeout=25)
        except HTTPError as error: reply = error
        with reply:
            raw = reply.read(LIMIT + 1)
            if len(raw) > LIMIT: raise ValueError('body exceeds 8 MiB limit')
            record.update(status=reply.status, final_url=reply.url,
                          response_headers={k: v for k,v in reply.headers.items() if k.lower() != 'set-cookie'},
                          bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                          body_file=name+suffix)
            (OUT/(name+suffix)).write_bytes(raw)
    except Exception as error:
        record['error'] = str(error)
    (OUT/(name+'.http.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:record[k] for k in ('name','status','bytes','error') if k in record}, ensure_ascii=False), flush=True)
    return record

def run():
    keyword = '狂飙'
    qq_search = dict(version='25071701',clientType=1,filterValue='',uuid='protocol-study-local',
        query=keyword,retry=0,pagenum=0,isPrefetch=True,pagesize=10,queryFrom=0,
        searchDatakey='',transInfo='',isneedQc=True,preQid='',adClientInfo='',
        extraInfo=dict(multi_terminal_pc='1',themeType='1',sugRelatedIds='{}',appVersion=''))
    iq_params=dict(key=keyword,current_page='1',mode='1',source='input',suggest='',pcv='13.074.22699',
        version='13.074.22699',pageNum='1',pageSize='10',pu='',u='protocol-study-local',scale='200',
        token='',userVip='0',conduit='',vipType='-1',os='',osShortName='win10',dataType='',appMode='',
        ad=json.dumps(dict(lm=3,azd=1000000000951,azt=733,position='feed'),separators=(',',':')),
        adExt='{"r":"2.1.5-ares6-pure"}')
    tvid='2176777301438100'
    sign=hashlib.md5(f'{tvid}_60_1cbzuw1259a'.encode()).hexdigest()[-8:]
    jobs=[
        ('qq-base','https://dm.video.qq.com/barrage/base/c4102g9a01t'),
        ('qq-search','https://pbaccess.video.qq.com/trpc.videosearch.mobile_search.MultiTerminalSearch/MbSearch?vplatform=2',qq_search,{'Origin':'https://v.qq.com','Referer':'https://v.qq.com/'}),
        ('iq-search','https://mesh.if.iqiyi.com/portal/lw/search/homePageV3?'+urlencode(iq_params),None,{'Origin':'https://www.iqiyi.com','Referer':'https://www.iqiyi.com/'}),
        ('iq-baseinfo','https://pcw-api.iqiyi.com/video/video/baseinfo/'+tvid),
        ('iq-segment',f'https://cmts.iqiyi.com/bullet/{tvid[-4:-2]}/{tvid[-2:]}/{tvid}_60_1_{sign}.br',None,None,'.br'),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        records=list(pool.map(lambda x:probe(*x),jobs))
    try:
        base=json.loads((OUT/'qq-base.json').read_bytes())
        segments=sorted(base['segment_index'].values(), key=lambda x:int(x['segment_start']))
        if segments:
            records.append(probe('qq-segment','https://dm.video.qq.com/barrage/segment/c4102g9a01t/'+segments[0]['segment_name']))
    except Exception as error: print('qq segment skipped: '+str(error),flush=True)
    (OUT/'probe-manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if __name__ == '__main__': run()
