"""Fetch fixed public source snapshots for protocol analysis; execute no target code."""
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.request import Request, urlopen
import zipfile
import io

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
for name in ['reference','evidence','examples','api']:(ROOT/name).mkdir(exist_ok=True)
REPOS=[('danmu_api','huangxd-/danmu_api','5ef63a01bae7c4bad4dcd7bafbbcdcf33aa82564'),
       ('danmaku_go','tamersunion/danmaku','1b940aa836d3eac0264745e912b1ff0b5d9dcae4')]
records=[]
def get(url,limit=64*1024*1024):
    with urlopen(Request(url,headers={'User-Agent':'DanmakuProtocolStudy/1.0'}),timeout=30) as reply:
        data=reply.read(limit+1)
        if len(data)>limit:raise ValueError('bounded download limit exceeded')
        return data
for name,repo,commit in REPOS:
    try:
        archive_url=f'https://codeload.github.com/{repo}/zip/{commit}'
        archive_path=ROOT/'reference'/f'{name}-source.zip'
        content=archive_path.read_bytes() if archive_path.exists() else get(archive_url)
        archive_path.write_bytes(content)
        destination=ROOT/'reference'/name
        destination.mkdir(exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            for entry in archive.infolist():
                parts=Path(entry.filename).parts[1:]
                if not parts:continue
                path=destination.joinpath(*parts)
                if not path.resolve().is_relative_to(destination.resolve()):raise ValueError('unsafe archive member')
                if entry.is_dir():path.mkdir(parents=True,exist_ok=True)
                else:
                    path.parent.mkdir(parents=True,exist_ok=True)
                    path.write_bytes(archive.read(entry))
        record={'name':name,'repository':repo,'commit':commit,'archive_url':archive_url,
                'archive_sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)}
        records.append(record)
        print(json.dumps(record,ensure_ascii=False),flush=True)
    except Exception as error:
        print(json.dumps({'repository':repo,'error':str(error)},ensure_ascii=False),flush=True)
(ROOT/'evidence/source-manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
